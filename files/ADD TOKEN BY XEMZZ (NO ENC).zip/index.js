/*
BEBAS RENAME
JUAL? GW EWE SAMPE LUMPUH😹
NodeJS: 18
- t.me/XemzzXiterz
*/
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const config = require('./settings/config');
const gitConfig = require('./settings/git');

const Xemzzbot = new TelegramBot(config.token, { polling: true });

const XemzztokensFile = path.join(__dirname, 'tokens.json');
const XemzzresellersFile = path.join(__dirname, 'resellers.json');
const XemzzadminFile = path.join(__dirname, 'admin.json');

function XemzzbacaFileJSON(filePath) {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

function XemzztulisFileJSON(filePath, data) {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

async function XemzzuploadKeGitHub() {
    try {
        const content = fs.readFileSync(XemzztokensFile, 'utf8');
        const contentBase64 = Buffer.from(content).toString('base64');
        
        const getUrl = `https://api.github.com/repos/${gitConfig.namaGithub}/${gitConfig.repoGithub}/contents/${gitConfig.namaFile}`;
        const headers = {
            'Authorization': `token ${gitConfig.githubToken}`,
            'User-Agent': 'XemzzBot'
        };

        let sha = null;
        try {
            const response = await axios.get(getUrl, { headers });
            sha = response.data.sha;
            
         
            if (response.data.content.replace(/\s/g, '') === contentBase64.replace(/\s/g, '')) {
                return true;
            }
        } catch (error) {
        }

        const data = {
            message: 'Update tokens.json oleh XemzzBot',
            content: contentBase64,
            sha: sha
        };

        const uploadUrl = `https://api.github.com/repos/${gitConfig.namaGithub}/${gitConfig.repoGithub}/contents/${gitConfig.namaFile}`;
        await axios.put(uploadUrl, data, { headers });
        
        return true;
    } catch (error) {
        return false;
    }
}

function XemzzcekAkses(userId, command) {
    if (userId == config.XemzzId) return true;
    
    const XemzzadminList = XemzzbacaFileJSON(XemzzadminFile);
    const XemzzresellerList = XemzzbacaFileJSON(XemzzresellersFile);
    
    const XemzzisAdmin = XemzzadminList.includes(userId.toString());
    
    const XemzzisReseller = XemzzresellerList.includes(userId.toString());
    
    if (command === '/addadmin' || command === '/deladmin') {
        return false;
    } else if (command === '/addakses' || command === '/delakses' || command === '/listakses') {
        return XemzzisAdmin;
    } else if (command === '/addtoken' || command === '/deltoken' || command === '/listtoken') {
        return XemzzisAdmin || XemzzisReseller;
    } else if (command === '/cekbot') {
        return XemzzisAdmin || XemzzisReseller;
    }
    
    return false;
}

async function XemzzdapatkanInfoBot(tokenBot) {
    try {
        const response = await axios.get(`https://api.telegram.org/bot${tokenBot}/getMe`);
        
        if (response.data.ok) {
            const botInfo = response.data.result;
            
            let photoUrl = null;
            let status = 'Tidak diketahui';
            
            try {
                const userPhotosResponse = await axios.get(`https://api.telegram.org/bot${tokenBot}/getUserProfilePhotos`, {
                    params: {
                        user_id: botInfo.id,
                        limit: 1
                    }
                });
                
                if (userPhotosResponse.data.ok && userPhotosResponse.data.result.total_count > 0) {
                    const fileId = userPhotosResponse.data.result.photos[0][0].file_id;
                    const fileResponse = await axios.get(`https://api.telegram.org/bot${tokenBot}/getFile`, {
                        params: { file_id: fileId }
                    });
                    
                    if (fileResponse.data.ok) {
                        photoUrl = `https://api.telegram.org/file/bot${tokenBot}/${fileResponse.data.result.file_path}`;
                    }
                    status = 'Aktif';
                } else {
                    status = 'Tidak aktif';
                }
            } catch (error) {
                status = 'Error mendapatkan status';
            }
            
            return {
                name: botInfo.first_name,
                username: botInfo.username,
                id: botInfo.id,
                bio: 'Tidak ada bio',
                status: status,
                photoUrl: photoUrl
            };
        } else {
            throw new Error('Token tidak valid');
        }
    } catch (error) {
        throw new Error('Token tidak valid atau bot tidak ditemukan');
    }
}

Xemzzbot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const photoPath = path.join(__dirname, './foto/xemzz.png');
    
    if (fs.existsSync(photoPath)) {
        Xemzzbot.sendPhoto(chatId, photoPath, {
            caption: `<blockquote>┏━━〘 TENTANG 〙
┃ ▢ Author : @OxBimz
┃ ▢ Version : 1.0
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 TOKEN 〕
╽ ▢ /addtoken &lt;token&gt;
╿ ▢ /deltoken &lt;token&gt;
╿ ▢ /listtoken
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 RESELLERS 〕
╽ ▢ /addakses &lt;id&gt;
╽ ▢ /delakses &lt;id&gt;
╿ ▢ /listakses
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 ADMIN 〕
╿ ▢ /addadmin &lt;id&gt;
╿ ▢ /deladmin &lt;id&gt;
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 TOOLS 〕
╿ ▢ /cekbot &lt;token&gt;
┕━━━━━━━━━━━━━━━━━━━</blockquote>`,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "DEVELOPER", url: "https://t.me/@OxBimz" }]
                ]
            }
        });
    } else {
        Xemzzbot.sendMessage(chatId, `<blockquote>┏━━〘 TENTANG 〙
┃ ▢ Author : @OxBimz
┃ ▢ Version : 1.0
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 TOKEN 〕
╽ ▢ /addtoken &lt;token&gt;
╿ ▢ /deltoken &lt;token&gt;
╿ ▢ /listtoken
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 RESELLERS 〕
╽ ▢ /addakses &lt;id&gt;
╽ ▢ /delakses &lt;id&gt;
╿ ▢ /listakses
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 ADMIN 〕
╿ ▢ /addadmin &lt;id&gt;
╿ ▢ /deladmin &lt;id&gt;
┕━━━━━━━━━━━━━━━━━━━</blockquote>

<blockquote>┏━━〔 TOOLS 〕
╿ ▢ /cekbot &lt;token&gt;
┕━━━━━━━━━━━━━━━━━━━</blockquote>`, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: "DEVELOPER", url: "https://t.me/@OxBimz" }]
                ]
            }
        });
    }
});

Xemzzbot.onText(/\/addtoken (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const tokenBot = match[1];
    
    if (!XemzzcekAkses(userId, '/addtoken')) {
        return Xemzzbot.sendMessage(chatId, '❌ Anda tidak memiliki akses untuk menambah token.');
    }
    
    try {
        await XemzzdapatkanInfoBot(tokenBot);
        
        const tokens = XemzzbacaFileJSON(XemzztokensFile);
        if (tokens.includes(tokenBot)) {
            return Xemzzbot.sendMessage(chatId, '❌ Token sudah ada dalam daftar.');
        }
        
        tokens.push(tokenBot);
        XemzztulisFileJSON(XemzztokensFile, tokens);
        
        const success = await XemzzuploadKeGitHub();
        
        if (success) {
            Xemzzbot.sendMessage(chatId, '✅ Token berhasil ditambahkan dan diupload ke GitHub.');
        } else {
            Xemzzbot.sendMessage(chatId, '✅ Token berhasil ditambahkan, tetapi gagal upload ke GitHub.');
        }
    } catch (error) {
        Xemzzbot.sendMessage(chatId, `❌ Gagal menambah token: ${error.message}`);
    }
});

Xemzzbot.onText(/\/deltoken (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const tokenBot = match[1];
    
    if (!XemzzcekAkses(userId, '/deltoken')) {
        return Xemzzbot.sendMessage(chatId, '❌ Anda tidak memiliki akses untuk menghapus token.');
    }
    
    try {
        const tokens = XemzzbacaFileJSON(XemzztokensFile);
        const index = tokens.indexOf(tokenBot);
        
        if (index === -1) {
            return Xemzzbot.sendMessage(chatId, '❌ Token tidak ditemukan dalam daftar.');
        }
        
        tokens.splice(index, 1);
        XemzztulisFileJSON(XemzztokensFile, tokens);
        
        const success = await XemzzuploadKeGitHub();
        
        if (success) {
            Xemzzbot.sendMessage(chatId, '✅ Token berhasil dihapus dan perubahan diupload ke GitHub.');
        } else {
            Xemzzbot.sendMessage(chatId, '✅ Token berhasil dihapus, tetapi gagal upload ke GitHub.');
        }
    } catch (error) {
        Xemzzbot.sendMessage(chatId, `❌ Gagal menghapus token: ${error.message}`);
    }
});

Xemzzbot.onText(/\/listtoken/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!XemzzcekAkses(userId, '/listtoken')) {
        return Xemzzbot.sendMessage(chatId, '❌ Anda tidak memiliki akses untuk melihat daftar token.');
    }
    
    const tokens = XemzzbacaFileJSON(XemzztokensFile);
    
    if (tokens.length === 0) {
        return Xemzzbot.sendMessage(chatId, '📝 Daftar token kosong.');
    }
    
    let message = '📋 Daftar Token:\n\n';
    tokens.forEach((token, index) => {
        message += `${index + 1}. ${token}\n`;
    });
    
    Xemzzbot.sendMessage(chatId, message);
});

Xemzzbot.onText(/\/addakses (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const targetUserId = match[1];
    
    if (!XemzzcekAkses(userId, '/addakses')) {
        return Xemzzbot.sendMessage(chatId, '❌ Anda tidak memiliki akses untuk menambah reseller.');
    }
    
    const resellers = XemzzbacaFileJSON(XemzzresellersFile);
    
    if (resellers.includes(targetUserId)) {
        return Xemzzbot.sendMessage(chatId, '❌ User sudah menjadi reseller.');
    }
    
    resellers.push(targetUserId);
    XemzztulisFileJSON(XemzzresellersFile, resellers);
    
    Xemzzbot.sendMessage(chatId, `✅ User ${targetUserId} berhasil ditambahkan sebagai reseller.`);
});

Xemzzbot.onText(/\/delakses (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const targetUserId = match[1];
    
    if (!XemzzcekAkses(userId, '/delakses')) {
        return Xemzzbot.sendMessage(chatId, '❌ Anda tidak memiliki akses untuk menghapus reseller.');
    }
    
    const resellers = XemzzbacaFileJSON(XemzzresellersFile);
    const index = resellers.indexOf(targetUserId);
    
    if (index === -1) {
        return Xemzzbot.sendMessage(chatId, '❌ User tidak ditemukan dalam daftar reseller.');
    }
    
    resellers.splice(index, 1);
    XemzztulisFileJSON(XemzzresellersFile, resellers);
    
    Xemzzbot.sendMessage(chatId, `✅ User ${targetUserId} berhasil dihapus dari reseller.`);
});

Xemzzbot.onText(/\/listakses/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!XemzzcekAkses(userId, '/listakses')) {
        return Xemzzbot.sendMessage(chatId, '❌ Anda tidak memiliki akses untuk melihat daftar reseller.');
    }
    
    const resellers = XemzzbacaFileJSON(XemzzresellersFile);
    
    if (resellers.length === 0) {
        return Xemzzbot.sendMessage(chatId, '📝 Daftar reseller kosong.');
    }
    
    let message = '📋 Daftar Reseller:\n\n';
    resellers.forEach((reseller, index) => {
        message += `${index + 1}. ${reseller}\n`;
    });
    
    Xemzzbot.sendMessage(chatId, message);
});

Xemzzbot.onText(/\/addadmin (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const targetUserId = match[1];
    
    if (userId != config.XemzzId) {
        return Xemzzbot.sendMessage(chatId, '❌ Hanya owner yang bisa menambah admin.');
    }
    
    const admins = XemzzbacaFileJSON(XemzzadminFile);
    
    if (admins.includes(targetUserId)) {
        return Xemzzbot.sendMessage(chatId, '❌ User sudah menjadi admin.');
    }
    
    admins.push(targetUserId);
    XemzztulisFileJSON(XemzzadminFile, admins);
    
    Xemzzbot.sendMessage(chatId, `✅ User ${targetUserId} berhasil ditambahkan sebagai admin.`);
});

Xemzzbot.onText(/\/deladmin (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const targetUserId = match[1];
    
    if (userId != config.XemzzId) {
        return Xemzzbot.sendMessage(chatId, '❌ Hanya owner yang bisa menghapus admin.');
    }
    
    const admins = XemzzbacaFileJSON(XemzzadminFile);
    const index = admins.indexOf(targetUserId);
    
    if (index === -1) {
        return Xemzzbot.sendMessage(chatId, '❌ User tidak ditemukan dalam daftar admin.');
    }
    
    admins.splice(index, 1);
    XemzztulisFileJSON(XemzzadminFile, admins);
    
    Xemzzbot.sendMessage(chatId, `✅ User ${targetUserId} berhasil dihapus dari admin.`);
});

Xemzzbot.onText(/\/cekbot (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const tokenBot = match[1];
    
    if (!XemzzcekAkses(userId, '/cekbot')) {
        return Xemzzbot.sendMessage(chatId, '❌ Anda tidak memiliki akses untuk mengecek bot.');
    }
    
    try {
        const info = await XemzzdapatkanInfoBot(tokenBot);
        
        if (info.photoUrl) {
            try {
                const photoResponse = await axios.get(info.photoUrl, { responseType: 'arraybuffer' });
                const photoBuffer = Buffer.from(photoResponse.data);
                
                Xemzzbot.sendPhoto(chatId, photoBuffer, {
                    caption: `<blockquote>INFORMASI BOT</blockquote>
<blockquote>Name: ${info.name}</blockquote>
<blockquote>Username: @${info.username}</blockquote>
<blockquote>ID: ${info.id}</blockquote>
<blockquote>Bio: ${info.bio}</blockquote>
<blockquote>Status: ${info.status}</blockquote>`,
                    parse_mode: 'HTML'
                });
            } catch (error) {
                Xemzzbot.sendMessage(chatId, `<blockquote>INFORMASI BOT</blockquote>
<blockquote>Name: ${info.name}</blockquote>
<blockquote>Username: @${info.username}</blockquote>
<blockquote>ID: ${info.id}</blockquote>
<blockquote>Bio: ${info.bio}</blockquote>
<blockquote>Status: ${info.status}</blockquote>`, {
                    parse_mode: 'HTML'
                });
            }
        } else {
            Xemzzbot.sendMessage(chatId, `<blockquote>INFORMASI BOT</blockquote>
<blockquote>Name: ${info.name}</blockquote>
<blockquote>Username: @${info.username}</blockquote>
<blockquote>ID: ${info.id}</blockquote>
<blockquote>Bio: ${info.bio}</blockquote>
<blockquote>Status: ${info.status}</blockquote>`, {
                parse_mode: 'HTML'
            });
        }
    } catch (error) {
        Xemzzbot.sendMessage(chatId, `❌ Gagal mengecek bot: ${error.message}`);
    }
});

console.log('udah wak');