module.exports = {
    token: '7991698602:AAHeDT7xV1uCznGfA3_NV2p_AZJDImLE4yE',
    XemzzId: '7780828553'
};