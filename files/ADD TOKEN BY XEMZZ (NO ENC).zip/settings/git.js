module.exports = {
    githubToken: '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',
    namaGithub: 'bimzhost',
    repoGithub: 'tokenlistdewabimz',
    namaFile: 'tokens.json'
};