 /*  
 * this code was created with assistance from chatgpt  
 * feature logic developed by kyuurzy
 */
 
module.exports = {
    apiId: Api_Id_lu,
    apiHash: "Api_hash_lu",
    sessionFile: "session.json",
    ownerId: 8085593314,
};
