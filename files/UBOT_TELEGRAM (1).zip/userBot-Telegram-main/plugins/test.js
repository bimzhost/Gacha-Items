 /*  
 * this code was created with assistance from chatgpt  
 * feature logic developed by kyuurzy
 */

module.exports = {
    command: ["tes"],
    run: async ({ client, text, reply }) => {
        reply(`on`);
    },
};