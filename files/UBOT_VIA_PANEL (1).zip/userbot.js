const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const input = require("input");
const fs = require("fs");

// === API ID & API HASH ===
const apiId = 25683949; // ganti
const apiHash = "5a0f1b821252088fe36c523c01c82533"; // ganti

// Lokasi file session & blacklist
const SESSION_FILE = "session.json";
const BLACKLIST_FILE = "blacklist.json";

// === FOOTER ===
const withFooter = (text) => {
  return `${text}\n\nUnbot By | TZY | Rann`;
};

// Load blacklist
let blacklist = [];
if (fs.existsSync(BLACKLIST_FILE)) {
  try {
    blacklist = JSON.parse(fs.readFileSync(BLACKLIST_FILE));
  } catch (e) {
    console.log("❌ File blacklist corrupt, buat baru");
    blacklist = [];
  }
}
const saveBlacklist = () => {
  fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(blacklist, null, 2));
};

// Baca session dari file
let savedSession = "";
if (fs.existsSync(SESSION_FILE)) {
  try {
    const data = JSON.parse(fs.readFileSync(SESSION_FILE));
    savedSession = data.session || "";
  } catch (e) {
    console.log("❌ Session corrupt, login ulang diperlukan");
  }
}
const stringSession = new StringSession(savedSession);

// === Variabel AFK ===
let isAfk = false;
let afkReason = "";

(async () => {
  console.log("=== Telegram UserBot Start ===");

  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  });

  if (!savedSession) {
    await client.start({
      phoneNumber: async () => {
        console.log("=== LOGIN TELEGRAM ===");
        console.log("📱 Silakan masukkan nomor telepon Anda (+62xxx):");
        return await input.text("> Nomor: ");
      },
      phoneCode: async () => {
        console.log("📩 Telegram sudah mengirimkan kode OTP ke akun Anda.");
        console.log("Silakan masukkan kode OTP (biasanya 5 digit):");
        return await input.text("> OTP: ");
      },
      password: async () => {
        console.log("🔑 Akun Anda menggunakan verifikasi dua langkah (2FA).");
        console.log("Masukkan sandi/password 2FA:");
        return await input.text("> Password 2FA: ");
      },
      onError: (err) => console.log("❌ Error:", err),
    });

    fs.writeFileSync(
      SESSION_FILE,
      JSON.stringify({ session: client.session.save() }, null, 2)
    );
    console.log("💾 Session baru disimpan ke", SESSION_FILE);
  } else {
    await client.connect();
    console.log("✅ Auto-login pakai session.json");
  }

  const me = await client.getMe();
  const myId = me.id.toString();

  await client.sendMessage("me", { message: withFooter("UserBot aktif 🚀") });

  // === EVENT HANDLER ===
  client.addEventHandler(
    async (event) => {
      const msg = event.message;
      if (!msg || !msg.message) return;
      const text = msg.message.trim();

      // ================= AFK FEATURE =================
      if (msg.senderId.toString() === myId) {
        // .afk <alasan>
        if (text.startsWith(".afk")) {
          const reason = text.split(" ").slice(1).join(" ") || "Tidak ada keterangan";
          isAfk = true;
          afkReason = reason;
          await client.sendMessage(msg.chatId, {
            message: withFooter(`✅ Mode AFK diaktifkan!\nKeterangan: ${reason}`),
            replyTo: msg.id,
          });
          return;
        }

        // .unafk
        if (text === ".unafk") {
          isAfk = false;
          afkReason = "";
          await client.sendMessage(msg.chatId, {
            message: withFooter("✅ Mode AFK dinonaktifkan!"),
            replyTo: msg.id,
          });
          return;
        }
      } else {
        if (isAfk) {
          let shouldReply = false;

          if (msg.isReply) {
            const replyMsg = await msg.getReplyMessage();
            if (replyMsg && replyMsg.senderId.toString() === myId) {
              shouldReply = true;
            }
          }

          if (msg.chatId.toString() === msg.senderId.toString()) {
            shouldReply = true;
          }

          if (shouldReply) {
            await client.sendMessage(msg.chatId, {
              message: withFooter(`💤 SEDANG AFK\n📝 KETERANGAN: ${afkReason}`),
              replyTo: msg.id,
            });
          }
        }
      }

      // ---------------- COMMANDS ----------------
      if (msg.senderId.toString() !== myId) return;

      // .ping
      if (text === ".ping") {
        const start = Date.now();
        let sent = await client.sendMessage(msg.chatId, {
          message: withFooter("Yameteh."),
          replyTo: msg.id,
        });

        setTimeout(async () => {
          try {
            await client.editMessage(sent.chatId, { message: sent.id, text: withFooter("Kudasai..") });
          } catch {}
        }, 300);

        setTimeout(async () => {
          try {
            await client.editMessage(sent.chatId, { message: sent.id, text: withFooter("Ahh Crot...") });
          } catch {}
        }, 600);

        setTimeout(async () => {
          const latency = Date.now() - start;
          try {
            await client.editMessage(sent.chatId, {
              message: sent.id,
              text: withFooter(`Crot Nya Enak!\n⚡ ${latency} ms`),
            });
          } catch {}
        }, 900);

        return;
      }

      // .addbl
      if (text.startsWith(".addbl")) {
        if (!msg.isGroup) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Hanya di grup!"), replyTo: msg.id });
          return;
        }
        const groupName = msg.chat.title || "Group";
        if (!blacklist.includes(msg.chatId.toString())) {
          blacklist.push(msg.chatId.toString());
          saveBlacklist();
          await client.sendMessage(msg.chatId, {
            message: withFooter(`✅ Grup *${groupName}* ditambahkan ke blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        } else {
          await client.sendMessage(msg.chatId, {
            message: withFooter(`⚠️ Grup *${groupName}* sudah ada di blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        }
        return;
      }

      // .deladdbl
      if (text.startsWith(".deladdbl")) {
        if (!msg.isGroup) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Hanya di grup!"), replyTo: msg.id });
          return;
        }
        const groupName = msg.chat.title || "Group";
        if (blacklist.includes(msg.chatId.toString())) {
          blacklist = blacklist.filter((id) => id !== msg.chatId.toString());
          saveBlacklist();
          await client.sendMessage(msg.chatId, {
            message: withFooter(`✅ Grup *${groupName}* dihapus dari blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        } else {
          await client.sendMessage(msg.chatId, {
            message: withFooter(`⚠️ Grup *${groupName}* tidak ada di blacklist.`),
            parseMode: "md",
            replyTo: msg.id,
          });
        }
        return;
      }

      // .cfdgroup
      if (text === ".cfdgroup") {
        if (!msg.replyTo) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Harus reply pesan!"), replyTo: msg.id });
          return;
        }
        const replyMsg = await msg.getReplyMessage();
        const dialogs = await client.getDialogs();
        let count = 0;
        for (const dialog of dialogs) {
          if (dialog.isGroup && !blacklist.includes(dialog.id.toString())) {
            try {
              await client.forwardMessages(dialog.id, { messages: replyMsg.id, fromPeer: msg.chatId });
              count++;
            } catch {}
          }
        }
        await client.sendMessage(msg.chatId, {
          message: withFooter(`✅ Pesan diteruskan ke ${count} grup.`),
          replyTo: msg.id,
        });
        return;
      }

      // .gikes
      if (text === ".gikes") {
        if (!msg.replyTo) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Harus reply pesan!"), replyTo: msg.id });
          return;
        }
        const replyMsg = await msg.getReplyMessage();
        if (!replyMsg || !replyMsg.message) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Tidak ada teks!"), replyTo: msg.id });
          return;
        }
        const copyText = replyMsg.message;
        const dialogs = await client.getDialogs();
        let count = 0;
        for (const dialog of dialogs) {
          if (dialog.isGroup && !blacklist.includes(dialog.id.toString())) {
            try {
              await client.sendMessage(dialog.id, { message: withFooter(copyText) });
              count++;
            } catch {}
          }
        }
        await client.sendMessage(msg.chatId, {
          message: withFooter(`✅ Pesan dikirim ke ${count} grup.`),
          replyTo: msg.id,
        });
        return;
      }

      // .spam jumlah
      if (text.startsWith(".spam")) {
        if (!msg.replyTo) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Harus reply pesan!"), replyTo: msg.id });
          return;
        }
        const parts = text.split(" ");
        if (parts.length < 2 || isNaN(parts[1])) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Format salah!\n.spam jumlah"), replyTo: msg.id });
          return;
        }
        const count = parseInt(parts[1]);
        const replyMsg = await msg.getReplyMessage();
        if (!replyMsg) {
          await client.sendMessage(msg.chatId, { message: withFooter("⚠️ Tidak ada pesan!"), replyTo: msg.id });
          return;
        }
        for (let i = 0; i < count; i++) {
          try {
            if (replyMsg.media) {
              await client.forwardMessages(msg.chatId, { messages: replyMsg.id, fromPeer: msg.chatId });
            } else if (replyMsg.message) {
              await client.sendMessage(msg.chatId, { message: withFooter(replyMsg.message) });
            }
          } catch {}
        }
        await client.sendMessage(msg.chatId, {
          message: withFooter(`✅ Spam selesai! ${count}x terkirim.`),
          replyTo: msg.id,
        });
        return;
      }

      // .help
      if (text === ".help") {
        const features = [
          { cmd: ".ping", desc: "Cek kecepatan respon UserBot" },
          { cmd: ".addbl", desc: "Tambah grup ke blacklist" },
          { cmd: ".deladdbl", desc: "Hapus grup dari blacklist" },
          { cmd: ".cfdgroup", desc: "Forward pesan reply ke semua grup" },
          { cmd: ".gikes", desc: "Copy teks reply & kirim ke semua grup" },
          { cmd: ".spam jumlah", desc: "Spam pesan reply sesuai jumlah" },
          { cmd: ".afk alasan", desc: "Aktifkan mode AFK dengan alasan" },
          { cmd: ".unafk", desc: "Nonaktifkan mode AFK" },
        ];
        let helpMessage = "📌 *Daftar Fitur UserBot*\n\n";
        features.forEach((f, i) => {
          helpMessage += `${i + 1}️⃣ ${f.cmd}\n   ➤ ${f.desc}\n\n`;
        });
        await client.sendMessage(msg.chatId, { 
          message: withFooter(helpMessage), 
          parseMode: "md", 
          replyTo: msg.id 
        });
        return;
      }
    },
    new NewMessage({})
  );
})();