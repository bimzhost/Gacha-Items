require("./settings")

const {
    Telegraf,
    Context,
    Markup
} = require('telegraf')
const {
    message,
    editedMessage,
    channelPost,
    editedChannelPost,
    callbackQuery
} = require("telegraf/filters");
const {toFirstCase,
        isNumber,
        formatp,
        parseMention, 
        resize, 
        getRandom,
        generateProfilePicture, 
        getCase, 
        runtime, 
        FileSize, 
        h2k, 
        makeid, 
        kyun, 
        randomNomor, 
        jsonformat, 
        isUrl,
        fetchJson, 
        sleep,
        getBuffer
        } = require("./lib/myfunc2");
        const Func = require('./lib/myfunc2')
        const { formatSize } = require("./lib/myfunc3");
const chalk = require('chalk')
const fs = require('fs')
const moment = require('moment-timezone');
const fetch = require('node-fetch')
const os = require('os')
const speed = require('performance-now')
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const util = require('util')
const yts = require('yt-search')
const axios = require('axios');
const crypto = require('crypto');
const path = require("path");
const { spawn, exec, execSync } = require('child_process');
const { fetchGameList, fetchProductList, fetchGameListt, searchProduct, checkTransactionExists, addTransaction, getTotalRefID, fetchTopup } = require("./lib/orderkuota");
const {
    simple
} = require('./lib/myfunc')
const hxz = require ("hxz-api")
let pj = '`'
global.db.data = JSON.parse(fs.readFileSync('./database/database.json'))
if (global.db.data) global.db.data = {
sticker: {},
database: {}, 
game: {},
others: {},
users: {},
chats: {},
settings: {},
...(global.db.data || {})
}

module.exports = rioo = async (rioo, m, bot) => {    
require('./lib/schema')(rioo, m)
    try {

        const body = rioo.message.text || rioo.message.caption || ''
        const budy = (typeof rioo.message.text == 'string' ? rioo.message.text : '')
        const {
            isUrl
        } = simple
        const isCmd = /^[°•π÷×¶∆£¢€¥®™�✓_=|~!?#/$%^&.+-,\\\©^]/.test(body)        
        const args = body.trim().split(/ +/).slice(1)
        const text = q = args.join(" ")
        const user = simple.getUserName(rioo.message.from)
        const user_id = rioo.message.from.id + " "
        const quoted = m.quoted ? m.quoted : m
        const pushname = user.full_name;
        const username = rioo.message.from.username ? rioo.message.from.username : "i_riza";
        const isCreator = OWNER[0].replace("https://t.me/", '') == rioo.update.message.from.username
        const sender = rioo.message.chat.id
        const prefix = isCmd ? body[0] : ''
        const command = isCreator ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : isCmd ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
        const isGroup = rioo.chat.type.includes('group')
        const groupName = isGroup ? rioo.chat.title : ''
        const isPremium = global.db.data.users[sender].premium
        const isImage = rioo.message.hasOwnProperty('photo')
        const isVideo = rioo.message.hasOwnProperty('video')
        const isAudio = rioo.message.hasOwnProperty('audio')
        const isSticker = rioo.message.hasOwnProperty('sticker')
        const isContact = rioo.message.hasOwnProperty('contact')
        const isLocation = rioo.message.hasOwnProperty('location')
        const isDocument = rioo.message.hasOwnProperty('document')
        const isAnimation = rioo.message.hasOwnProperty('animation')
        const isMedia = isImage || isVideo || isAudio || isSticker || isContact || isLocation || isDocument || isAnimation
        const quotedMessage = rioo.message.reply_to_message || {}
        const isQuotedImage = quotedMessage.hasOwnProperty('photo')
        const isQuotedVideo = quotedMessage.hasOwnProperty('video')
        const isQuotedAudio = quotedMessage.hasOwnProperty('audio')
        const isQuotedSticker = quotedMessage.hasOwnProperty('sticker')
        const isQuotedContact = quotedMessage.hasOwnProperty('contact')
        const isQuotedLocation = quotedMessage.hasOwnProperty('location')
        const isQuotedDocument = quotedMessage.hasOwnProperty('document')
        const isQuotedAnimation = quotedMessage.hasOwnProperty('animation')
        const isQuoted = rioo.message.hasOwnProperty('reply_to_message')
        

const reply = async (text) => {
    await rioo.replyWithMarkdown(text, {
        disable_web_page_preview: true
    });
};
const tagBot = BOT_TAG;
const getStyle = (style_, style, style2) => {
    let listt = `${lang.getStyle(style, style2)}\n`;
    for (let i = 0; i < style_.length; i++) {
        listt += `» \`${style_[i]}\`\n`;
    }
    reply(listt);
};
const jam = moment.tz('Asia/Jakarta').format('HH:mm:ss')

        //get type message 
        var typeMessage = body.substr(0, 50).replace(/\n/g, '')
        if (isImage) typeMessage = 'Image'
        else if (isVideo) typeMessage = 'Video'
        else if (isAudio) typeMessage = 'Audio'
        else if (isSticker) typeMessage = 'Sticker'
        else if (isContact) typeMessage = 'Contact'
        else if (isLocation) typeMessage = 'Location'
        else if (isDocument) typeMessage = 'Document'
        else if (isAnimation) typeMessage = 'Animation'

        //push message to console
        if (rioo.message) {
           const a = isGroup ? "👥 Group" : "👤 Private";
            const b = body || typeMessage;
            console.log(
                `╭─ • 乂 ${chalk.magenta(a)}\n` +
                `│  ◦  👋 ${chalk.blue("FROM")}: ${chalk.yellow(pushname + " => ")}\n` +
                `│  ◦  ✉️ ${chalk.blue("MESSAGE")}: ${chalk.green(b)}\n` +
                `│  ◦  🕒 ${jam}\n` +
                `╰──── •` +
                ``
            );
/*let kenyataan = `
📬 𝗡𝗼𝘁𝗶𝗳𝗶𝗸𝗮𝘀𝗶 𝗣𝗲𝘀𝗮𝗻 𝗠𝗮𝘀𝘂𝗸
─────────────────────
👤 𝗦𝗲𝗻𝗱𝗲𝗿: @${username}
🆔 𝗦𝗲𝗻𝗱𝗲𝗿 𝗜𝗗: ${user_id}
📍 𝗜𝗻: ${a}
⏰ 𝗧𝗶𝗺𝗲: ${jam}

💬 𝗧𝗵𝗶𝘀 𝗠𝗲𝘀𝘀𝗮𝗴𝗲:
${b}

`;


try {
  await fetch(`https://api.telegram.org/bot7769812140:AAoddoJPKraDRg02c8G8T7e5D9-Yvz4/sendMessage?chat_id=${adminId}&text=${encodeURIComponent(kenyataan)}`);
} catch (err) {
  console.error('Gagal kirim ke Telegram:', err);
}*/
            }


const totalFitur = () =>{
            var mytext = fs.readFileSync("./case.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
               
function generateSignature(memberID, Sproduk, dest, refID, pin, password) {
  const textToHash = `OtomaX${memberID}${Sproduk}${dest}${refID}${pin}${password}`;
  const hashedText = crypto.createHash('sha1').update(textToHash).digest('base64');
  return hashedText;
}
        
 const sendMessage = (chatId, text) => bot.sendMessage(chatId, text);
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}       
function no(number){
    return number.replace(/\s/g,'').replace(/([@+-])/g,'')
  }
function msToDate(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor(daysms / (60 * 60 * 1000));
    let hoursms = daysms % (60 * 60 * 1000);
    let minutes = Math.floor(hoursms / (60 * 1000));

    return `${days}:${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}

function formatDateTime(timestamp, region = 'WIB') {
    let timeZones = {
        'WIB': 'Asia/Jakarta',
        'WITA': 'Asia/Makassar',
        'WIT': 'Asia/Jayapura'
    };

    let timeZone = timeZones[region] || 'Asia/Jakarta';
    let date = new Date(timestamp);
    
    let options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        timeZone: timeZone,
        timeZoneName: 'short'
    };

    return date.toLocaleDateString('id-ID', options);
}

const ptcpPath = './database/participant.json';

if (rioo.chat.type.includes('group')) {
    let data = [];

    if (fs.existsSync(ptcpPath)) {
        try {
            data = JSON.parse(fs.readFileSync(ptcpPath));
        } catch (err) {
            console.error('Gagal membaca participant.json:', err);
        }
    }

    const groupId = String(rioo.chat.id);

    if (!data.includes(groupId)) {
        data.push(groupId);
        fs.writeFileSync(ptcpPath, JSON.stringify(data, null, 2));
        /*console.log(`[✓] Grup baru disimpan: ${groupId}`);*/
    }
}
async function downloadMediaMessage(ctx) {
  const doc = ctx.message?.reply_to_message?.document
  if (!doc) throw new Error('Tidak ada dokumen HTML yang di-reply.')

  const fileLink = await ctx.telegram.getFileLink(doc.file_id)
  const res = await fetch(fileLink.href)
  if (!res.ok) throw new Error(`Gagal download file: ${res.statusText}`)

  return await res.buffer()
}
switch (command) {
case 'start': {
    
  const userFile = './database/user.json';
  let userList = fs.existsSync(userFile) ? JSON.parse(fs.readFileSync(userFile)) : [];

  

  if (!userList.includes(user_id)) {
    userList.push(user_id);
    fs.writeFileSync(userFile, JSON.stringify(userList, null, 2));
  }


    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const formattedUsedMem = formatSize(usedMem);
    const formattedTotalMem = formatSize(totalMem);
    const currentDate = new Intl.DateTimeFormat('id-ID', { 
        timeZone: 'Asia/Jakarta', 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    }).format(new Date());

    const message = `
\`⟪ 𝗖𝗿𝗲𝗮𝘁𝗲 𝘀𝗰 - 𝗩𝗲𝗿𝘀𝗶 𝟮.𝟭.𝟬 ⟫\`
━ 𝗔𝗨𝗧𝗢𝗠𝗔𝗧𝗘𝗗 𝗦𝗬𝗦𝗧𝗘𝗠 ━

ʙᴏᴛ ɪɴɪ ʙᴇʀᴊᴀʟᴀɴ sᴇᴄᴀʀᴀ ᴏᴛᴏᴍᴀᴛɪs ᴅᴀɴ ᴍᴇɴʏᴇᴅɪᴀᴋᴀɴ ʙᴇʀʙᴀɢᴀɪ ʟᴀʏᴀɴᴀɴ, ғɪᴛᴜʀ, sᴇʀᴛᴀ ᴛᴏᴏʟs ʏᴀɴɢ sɪᴀᴘ ᴍᴇᴍʙᴀɴᴛᴜ ᴀᴋᴛɪᴠɪᴛᴀs ᴅɪɢɪᴛᴀʟᴍᴜ ᴅɪ ᴛᴇʟᴇɢʀᴀᴍ.

━ ━━━━━━━━━━━━━━━━ ━

┍▣ *𝗜𝗡𝗙𝗢 𝗕𝗢𝗧*
│› Nama: *Create Sc*
│› Versi: *2.1.0*
│› Mode: *Public*
│› Developer: *noxxa solo*
╰› Platform: *NodeJS*

┍▣ *𝗔𝗟𝗟 𝗙𝗜𝗧𝗨𝗥*
╰› */menu* — semua menu

┍▣ *𝗙𝗜𝗧𝗨𝗥 𝗜𝗡𝗙𝗢*
│› */cekid* — cek id telegram
│› */owner* — kontak owner
│› */ping* — cek status bot
╰› */donasi* — dukung kami

━ ━━━━━━━━━━━━━━━━ ━

© create script`;

    rioo.replyWithPhoto(
        global.pp, {
            caption: message,
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '𝐂𝐇𝐀𝐍𝐄𝐋', url: `https://t.me/allinfoscript` }]
                ],
                
                one_time_keyboard: true,
                resize_keyboard: true
            }
        }
    );
}
break;
case 'menu': {
    
  const userFile = './database/user.json';
  let userList = fs.existsSync(userFile) ? JSON.parse(fs.readFileSync(userFile)) : [];

  

  if (!userList.includes(user_id)) {
    userList.push(user_id);
    fs.writeFileSync(userFile, JSON.stringify(userList, null, 2));
  }


    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const formattedUsedMem = formatSize(usedMem);
    const formattedTotalMem = formatSize(totalMem);
    const currentDate = new Intl.DateTimeFormat('id-ID', { 
        timeZone: 'Asia/Jakarta', 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    }).format(new Date());

    const message = `
\`⟪ 𝗖𝗿𝗲𝗮𝘁𝗲 𝘀𝗰 - 𝗩𝗲𝗿𝘀𝗶 𝟮.𝟮.𝟬 ⟫\`
━ 𝗔𝗨𝗧𝗢𝗠𝗔𝗧𝗘𝗗 𝗦𝗬𝗦𝗧𝗘𝗠 ━

┍▣ *𝗖𝗥𝗘𝗔𝗧𝗘 𝗦𝗖𝗥𝗜𝗣𝗧*
│› */createsc* — buat skrip
│› */listfitur* — lihat fitur
│› */addfitur* — tambah fitur
│› */delfitur* — hapus fitur
╰› */getcasesc* — ambil fitur

┍▣ *𝗖𝗥𝗘𝗔𝗧𝗘 𝗪𝗘𝗕𝗦𝗜𝗧𝗘*
│› */createweb* — buat website
│› */listweb* — daftar website
╰› */delweb* — hapus website

┍▣ *𝗙𝗜𝗧𝗨𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚*
│› */totalfitur* — total fitur
│› */scase* — cari case
│› */listcase* — daftar case
╰› */getcase* — ambil case

┍▣ *𝗙𝗜𝗧𝗨𝗥 𝗢𝗥𝗞𝗨𝗧*
│› */orkut-depo* — deposit orkut
│› */orkut-beli* — beli produk
│› */mutasiqris* — qris mutasi
╰› */orkut-search* — cari produk

┍▣ *𝗙𝗜𝗧𝗨𝗥 𝗔𝗥𝗧𝗜𝗙𝗜𝗖𝗜𝗔𝗟*
│› */smart-ai* — smart ai
│› */blackboxai* — blackbox ai
│› */gemini* — gemini ai
│› */esia* — esia ai
│› */muslimai* — muslim ai
│› */luminai* — luminai
│› */deepseek* — deepseek ai
│› */meta* — meta ai
╰› */llama* — llama ai

┍▣ *𝗙𝗜𝗧𝗨𝗥 𝗦𝗛𝗔𝗥𝗘*
│› */broadcast* — bc to user
╰› */jpm* — share to grup

┍▣ *𝗙𝗜𝗧𝗨𝗥 𝗚𝗥𝗢𝗨𝗣*
│› */kick* — tendang member
│› */promote* — jadi admin
│› */demote* — hapus admin
│› */setsubject* — atur subject
╰› */setdesk* — atur desk

© create script`;

    rioo.replyWithPhoto(
        global.pp, {
            caption: message,
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '𝐂𝐇𝐀𝐍𝐄𝐋', url: `https://t.me/allinfoscript` }]
                ],
                
                one_time_keyboard: true,
                resize_keyboard: true
            }
        }
    );
}
break;
case 'getcase': {
       
    try {
        if (!isCreator) return rioo.reply("❗ *Access Denied*\nFitur Only `Owner`")
        if (!text) return rioo.reply('❌ Masukkan nama case!\n\nContoh: .getcase menu');
        const caseFilePath = './case.js'; // Sesuaikan dengan lokasi file case.js
        // Baca isi file case.js dan pecah menjadi array berdasarkan baris
        let caseFileContent = fs.readFileSync(caseFilePath, 'utf8');
        let caseLines = caseFileContent.split('\n');
        // Regex untuk mencari case "nama" atau case 'nama'
        let caseRegex = new RegExp(`^\\s*case\\s+['"]${text}['"]\\s*:`);
        let startLine = null;
        let endLine = null;
        let foundCase = null;
        // Loop untuk mencari case yang diminta
        for (let i = 0; i < caseLines.length; i++) {
            if (caseRegex.test(caseLines[i])) {
                startLine = i;
                foundCase = [];
                // Menyimpan isi case hingga menemukan `break;`
                for (let j = i; j < caseLines.length; j++) {
                    foundCase.push(caseLines[j]);
                    if (/^\s*break\s*/.test(caseLines[j])) {
                        endLine = j;
                        break;
                    }
                }
                break;
            }
        }
        if (!foundCase) return rioo.reply(`❌ Case *${text}* tidak ditemukan!`);
        // Gabungkan isi case menjadi teks
        let caseContent = foundCase.join('\n');
        // Pesan konfirmasi
rioo.reply(caseContent);
    } catch (error) {
        console.error('Error saat mencari case:', error);
        rioo.reply('❌ Gagal mencari case.');
    }
}
break
case 'listcase': {
  try {
    if (!isCreator) return rioo.reply("❗ *Access Denied*\nFitur Only `Owner`");

    const caseFilePath = './case.js';
    let caseFileContent = fs.readFileSync(caseFilePath, 'utf8');
    let caseLines = caseFileContent.split('\n');
    let caseRegex = /^\s*case\s+["']([^"']+)["']\s*:/;
    let caseList = [];
    let currentCase = null;

    for (let i = 0; i < caseLines.length; i++) {
      let match = caseLines[i].match(caseRegex);
      if (match) {
        if (currentCase) caseList.push(currentCase);
        currentCase = {
          name: match[1],
          start: i + 1,
          end: null,
        };
      }

      if (/^\s*break\s*;?/.test(caseLines[i]) && currentCase) {
        currentCase.end = i + 1;
        caseList.push(currentCase);
        currentCase = null;
      }
    }

    if (currentCase) caseList.push(currentCase);
    if (caseList.length === 0) return rioo.reply('❌ Tidak ada case yang ditemukan.');

    let teks = `[ Daftar Case Tersedia ]\n\n`;
    teks += caseList.map((item, i) => 
      `• ${i + 1}. ${item.name} [${item.start} | ${item.end}]`
    ).join('\n');

    rioo.reply(teks);
  } catch (error) {
    console.error('❌ Error saat mengambil daftar case:', error);
    rioo.reply('⚠️ Gagal mengambil daftar case.');
  }
}
break;
case 'broadcast': {
  if (!isCreator) return rioo.reply('❌ Fitur ini hanya untuk Creator!');
  if (!text) return rioo.reply('⚠️ Masukkan teks untuk broadcast.\nContoh: /broadcast Halo semua!');

  const userFile = './database/user.json';
  const userList = fs.existsSync(userFile) ? JSON.parse(fs.readFileSync(userFile)) : [];

  if (userList.length === 0) return rioo.reply('⚠️ Tidak ada pengguna yang terdaftar.');

  rioo.reply(`📢 Mengirim broadcast ke ${userList.length} pengguna...`);

  for (let userId of userList) {
    fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: userId,
        text: text,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Owner', url: 'https://t.me/noxxasoloo' }
            ],
            [
              { text: 'Public Room', url: 'https://t.me/roompublicnoxaa' }
            ]
          ]
        }
      })
    }).catch(e => {
      console.log(`❌ Gagal kirim ke ${userId}: ${e.message}`);
    });

    await new Promise(resolve => setTimeout(resolve, 3000));
  }

  rioo.reply('✅ Broadcast selesai dikirim.');
}
break;
case 'jpm': {
  if (!isCreator) return rioo.reply('❌ Fitur ini hanya untuk Creator!');
  if (!text) return rioo.reply('⚠️ Masukkan teks untuk broadcast.\nContoh: /jpm Halo semua!');

  const userFile = './database/participant.json';
  const userList = fs.existsSync(userFile) ? JSON.parse(fs.readFileSync(userFile)) : [];

  if (userList.length === 0) return rioo.reply('⚠️ Belum Ada grup yang terdaftar.');

  rioo.reply(`📢 Mengirim teks Jpm ke ${userList.length} grup...`);

  for (let userId of userList) {
    fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: userId,
        text: text,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Owner', url: 'https://t.me/noxxasoloo' }
            ],
            [
              { text: 'Public Room', url: 'https://t.me/roompublicnoxaa' }
            ]
          ]
        }
      })
    }).catch(e => {
      console.log(`❌ Gagal kirim ke ${userId}: ${e.message}`);
    });

    await new Promise(resolve => setTimeout(resolve, 3000));
  }

  rioo.reply('✅ teks Jpm selesai dikirim.');
}
break;
case 'smart-ai': {
    if (!text) return rioo.reply('Mohon Sertakan Pertanyaan');

    const prompt = `
Namamu adalah Arhiza, Asisten Berbasis Bot Telegram.
Tugasmu adalah menjawab setiap pertanyaan kami. Kamu memiliki fitur berikut:

1. ubah-subjek (mengubah nama grup)
2. ubah-deskripsi (mengubah deskripsi grup)
3. none

Respon kamu harus dan wajib menggunakan ### seperti ini.
Khusus fitur "none", kamu hanya menjawab pertanyaan pengguna secara santai dan sesingkat mungkin.

Contoh:
pengguna: halo, bisa kamu ubah nama grup ini menjadi Grup sahabat?
respon kamu: tentu!, sebentar
###ubah-subjek Grup sahabat###

baiklah, langsung saja jawab pertanyaan dari user kami:
User: ${text}
`;

    const urlai = `https://api.siputzx.my.id/api/ai/gemini-pro?content=${encodeURIComponent(prompt)}`
    const unfinish = await fetch(urlai);
    const finishh = await unfinish.json();
    const responAi = finishh.data;

    // Deteksi fitur dari footer
    const regexFitur = /###(.+?)###/;
    const match = responAi.match(regexFitur);
    const fiturRaw = match ? match[1].trim() : 'none';
    const fitur = fiturRaw.toLowerCase();

    // Bersihkan pesan dari footer
    const jawabanTanpaFooter = responAi.replace(regexFitur, '').trim();

    // Kirim balasan jika ada
    if (jawabanTanpaFooter.length > 0) {
        await rioo.reply(jawabanTanpaFooter);
    }

    // Eksekusi fitur berdasarkan hasil AI
    if (fitur.startsWith('ubah-subjek')) {
        if (!isGroup) return rioo.reply(mess.group);

        const user = await rioo.telegram.getChatMember(rioo.chat.id, rioo.from.id);
        if (!['administrator', 'creator'].includes(user.status)) return rioo.reply(mess.admin);

        const bot = await rioo.telegram.getChatMember(rioo.chat.id, rioo.botInfo.id);
        if (bot.status !== 'administrator') return rioo.reply(mess.botAdmin);

        const newName = fiturRaw.replace('ubah-subjek', '').trim();
        if (!newName) return rioo.reply('Masukkan nama grup baru!');
        await rioo.telegram.setChatTitle(rioo.chat.id, newName);
        return rioo.reply('Nama grup berhasil diubah!');
    }

    else if (fitur.startsWith('ubah-deskripsi')) {
        if (!isGroup) return rioo.reply(mess.group);

        const user = await rioo.telegram.getChatMember(rioo.chat.id, rioo.from.id);
        if (!['administrator', 'creator'].includes(user.status)) return rioo.reply(mess.admin);

        const bot = await rioo.telegram.getChatMember(rioo.chat.id, rioo.botInfo.id);
        if (bot.status !== 'administrator') return rioo.reply(mess.botAdmin);

        const newDesc = fiturRaw.replace('ubah-deskripsi', '').trim();
        if (!newDesc) return rioo.reply('Masukkan deskripsi grup baru!');
        await rioo.telegram.setChatDescription(rioo.chat.id, newDesc);
        return rioo.reply('Deskripsi grup berhasil diubah!');
    }

    // else if (fitur.startsWith('fitur-lain')) { ... }
}
break;
case 'setsubject':
        if (!isGroup) return rioo.reply(mess.group);

        const fijilu = await rioo.telegram.getChatMember(rioo.chat.id, rioo.from.id);
        if (fijilu.status !== 'administrator' && fijilu.status !== 'creator') {
            return rioo.reply(mess.admin);
        }

        const botInfo = await rioo.telegram.getChatMember(rioo.chat.id, rioo.botInfo.id);
        if (botInfo.status !== 'administrator' || !botInfo.can_promote_members) {
            return rioo.reply(mess.botAdmin);
        }

        if (!text) return rioo.reply(`*Please provide a new name or subject!* Example: ${prefix + command} New Group Name`);

        try {
            await rioo.telegram.setChatTitle(rioo.chat.id, text);
            return rioo.reply('Group name/subject updated successfully!');
        } catch (error) {
            return rioo.reply(`Error: ${error.message}`);
        }
break;
case 'setdesk':
        if (!isGroup) return rioo.reply(mess.group);

        const senderDesk = await rioo.telegram.getChatMember(rioo.chat.id, rioo.from.id);
        if (senderDesk.status !== 'administrator' && senderDesk.status !== 'creator') {
            return rioo.reply(mess.admin);
        }

        const botInfoDesk = await rioo.telegram.getChatMember(rioo.chat.id, rioo.botInfo.id);
        if (botInfoDesk.status !== 'administrator' || !botInfoDesk.can_promote_members) {
            return rioo.reply(mess.botAdmin);
        }

        if (!text) return rioo.reply(`*Please provide a new description!* Example: ${prefix + command} Welcome to the group!`);

        try {
            await rioo.telegram.setChatDescription(rioo.chat.id, text);
            return rioo.reply('Group description updated successfully!');
        } catch (error) {
            return rioo.reply(`Error: ${error.message}`);
        }
        break;
case 'promote': case 'pm': {
    if (!isGroup) return rioo.reply(mess.group);

    const sender = await rioo.telegram.getChatMember(rioo.chat.id, rioo.from.id);
    if (sender.status !== 'administrator' && sender.status !== 'creator') {
        return rioo.reply(mess.admin);
    }

    const botInfo = await rioo.telegram.getChatMember(rioo.chat.id, rioo.botInfo.id);
    if (botInfo.status !== 'administrator' || !botInfo.can_promote_members) {
        return rioo.reply(mess.botAdmin);
    }

    let userId = rioo.message.reply_to_message 
        ? rioo.message.reply_to_message.from.id 
        : (text ? text.replace(/\D/g, "") : null);

    if (!userId) {
        return rioo.reply("reply pesan target yang ingin dijadikan admin!");
    }

    try {
        const targetInfo = await rioo.telegram.getChatMember(rioo.chat.id, userId);
        if (targetInfo.status === 'creator') {
            return rioo.reply("Aku tidak bisa mempromosikan pemilik grup.");
        }

        await rioo.telegram.promoteChatMember(rioo.chat.id, userId, {
            can_manage_chat: true,
            can_delete_messages: true,
            can_invite_users: true,
            can_restrict_members: true,
            can_pin_messages: true,
            can_promote_members: false
        });

        rioo.reply(`✅ <a href="tg://user?id=${userId}">Pengguna</a> telah dipromosikan menjadi admin!`, { parse_mode: "HTML" });
    } catch (err) {
        console.error("Error saat mempromosikan:", err);
        if (err.message.includes("not enough rights")) {
            rioo.reply("❌ Aku tidak memiliki izin yang cukup untuk mempromosikan pengguna ini.");
        } else {
            rioo.reply("❌ Terjadi kesalahan saat mempromosikan pengguna.");
        }
    }
    break;
}

case 'demote': case 'dm': {
    if (!isGroup) return rioo.reply(mess.group);

    const sender = await rioo.telegram.getChatMember(rioo.chat.id, rioo.from.id);
    if (sender.status !== 'administrator' && sender.status !== 'creator') {
        return rioo.reply(mess.admin);
    }

    const botInfo = await rioo.telegram.getChatMember(rioo.chat.id, rioo.botInfo.id);
    if (botInfo.status !== 'administrator' || !botInfo.can_promote_members) {
        return rioo.reply(mess.botAdmin);
    }

    let userId = rioo.message.reply_to_message 
        ? rioo.message.reply_to_message.from.id 
        : (text ? text.replace(/\D/g, "") : null);

    if (!userId) {
        return rioo.reply("reply pesan target yang ingin di-unadmin!");
    }

    try {
        const targetInfo = await rioo.telegram.getChatMember(rioo.chat.id, userId);
        if (targetInfo.status !== 'administrator') {
            return rioo.reply("Pengguna ini bukan admin.");
        }

        if (targetInfo.status === 'creator') {
            return rioo.reply("Aku tidak bisa mencabut hak admin pemilik grup.");
        }

        await rioo.telegram.promoteChatMember(rioo.chat.id, userId, {
            can_manage_chat: false,
            can_delete_messages: false,
            can_invite_users: false,
            can_restrict_members: false,
            can_pin_messages: false,
            can_promote_members: false
        });

        rioo.reply(`✅ <a href="tg://user?id=${userId}">Pengguna</a> telah dihapus dari daftar admin!`, { parse_mode: "HTML" });
    } catch (err) {
        console.error("Error saat mencabut hak admin:", err);
        if (err.message.includes("not enough rights")) {
            rioo.reply("❌ Aku tidak memiliki izin yang cukup untuk mencabut hak admin pengguna ini.");
        } else {
            rioo.reply("❌ Terjadi kesalahan saat mencabut hak admin pengguna.");
        }
    }
    break;
}
case 'kick': {
if (!isGroup) return rioo.reply(mess.group)
    if (!rioo.message) return;
    const botInfo = await rioo.telegram.getChatMember(rioo.chat.id, rioo.botInfo.id);
    if (botInfo.status !== 'administrator') {
        return rioo.reply(mess.admin);
    }
    const sender = await rioo.telegram.getChatMember(rioo.chat.id, rioo.from.id);
    if (sender.status !== 'administrator' && sender.status !== 'creator') {
        return rioo.reply(mess.botAdmin);
    }
    let userId = rioo.message.reply_to_message 
        ? rioo.message.reply_to_message.from.id 
        : text.replace(/\D/g, "");

    if (!userId) {
        return rioo.reply("Harap mention atau balas pesan pengguna yang ingin dikeluarkan!");
    }

    const targetUser = await rioo.telegram.getChatMember(rioo.chat.id, userId);
    if (targetUser.status === 'administrator' || targetUser.status === 'creator') {
        return rioo.reply("Aku tidak bisa mengeluarkan admin atau pemilik grup.");
    }

    await rioo.telegram.banChatMember(rioo.chat.id, userId);
    await rioo.telegram.unbanChatMember(rioo.chat.id, userId);

    rioo.reply(`Maaf ya, <a href="tg://user?id=${userId}">pengguna</a>, kamu telah dikeluarkan oleh admin.`, {
        parse_mode: "HTML"
    });

    break;
}

case 'buyprem': {
    if (!text) return reply('❌ Masukkan durasi premium dalam hari. Contoh: .buyprem 30');

    const daysToAdd = parseInt(text.trim());
    if (isNaN(daysToAdd) || daysToAdd <= 0) {
        return reply('🚫 Durasi tidak valid. Pastikan hanya angka positif, contoh: .buyprem 30');
    }

    const pricePerDay = 1000;
    const totalPrice = daysToAdd * pricePerDay;

    try {
        const paymentResponse = await fetch(`https://api.botwa.riooxdzz.me/api/orkut/createpayment?amount=${totalPrice}&codeqr=${global.qrisOrderKuota}&apikey=${riiapikey}`);
        const paymentData = await paymentResponse.json();

        if (!paymentData.result || !paymentData.result.qrImageUrl.url) {
            throw new Error('Gagal membuat pembayaran, coba lagi nanti.');
        }

        const expirationTime = new Date(Date.now() + 5 * 60 * 1000);
        const formattedExpiration = expirationTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

        const paymentDetails = `🛒 *PEMBELIAN PREMIUM*\n\nDurasi: ${daysToAdd} Hari\nHarga: Rp ${totalPrice.toLocaleString('id-ID')}\nBatas Waktu: ${formattedExpiration}\n\nSilakan scan QRIS di bawah untuk melanjutkan pembayaran.`;

        let sentMessage = await rioo.replyWithPhoto({
            url: paymentData.result.qrImageUrl.url,
        }, {
            caption: paymentDetails
        });

        const statusApiUrl = `https://api.botwa.riooxdzz.me/api/orkut/cekstatus?merchant=${ord_id}&keyorkut=${ord_apikey}&apikey=${riiapikey}`;
        let isTransactionComplete = false;
        const maxWaitTime = 5 * 60 * 1000; // 5 menit
        const startTime = Date.now();

        while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
            try {
                const statusResponse = await axios.get(statusApiUrl);
                const statusData = statusResponse.data;

                if (statusData && statusData.amount && parseInt(statusData.amount) === totalPrice) {
                    isTransactionComplete = true;
                    const now = new Date().getTime();
                    const jumlahHari = 86400000 * daysToAdd;

                    if (global.db.data.users[sender].premium && global.db.data.users[sender].premiumDate > now) {
                        global.db.data.users[sender].premiumDate += jumlahHari;
                    } else {
                        global.db.data.users[sender].premium = true;
                        global.db.data.users[sender].premiumDate = now + jumlahHari;
                    }

                    let premiumDate = global.db.data.users[sender].premiumDate === Infinity 
                        ? "Unlimited" 
                        : msToDate(global.db.data.users[sender].premiumDate - now);

                    const successMessage = `✅ *PREMIUM BERHASIL AKTIF!*\n\nDurasi: ${daysToAdd} hari\nTotal Harga: Rp ${totalPrice.toLocaleString('id-ID')}\nMasa Aktif: ${premiumDate}\n\nTerima kasih telah membeli premium!`;
                    await reply(successMessage);
                    return;
                }
            } catch (error) {
                console.error('Error memeriksa status transaksi:', error);
            }

            await new Promise(resolve => setTimeout(resolve, 10000));
        }

        if (!isTransactionComplete) {
            const expiredText = `❌ *WAKTU PEMBAYARAN HABIS!*\n\nTransaksi Anda melebihi batas waktu pembayaran. Silakan coba lagi dengan membuat transaksi baru.`;
            await rioo.reply(expiredText);
        }
    } catch (error) {
        console.error('Error dalam pemrosesan pembayaran:', error);
        return rioo.reply('❌ Terjadi kesalahan saat memproses pembayaran. Silakan coba lagi nanti.');
    }
}
break
case 'cekid': {
const tekz = `• INFORMASI ID TELEGRAM •\n\n🔹 Nama: ${pushname}\n🆔 ID: ${user_id}`;
    return rioo.reply(tekz);
}
break;
case 'addfitur': {
    if (!isCreator) return rioo.reply("❗ Fitur Khusus Creator.");

    const args = text.split('•••');
    if (args.length < 3) return rioo.reply(`\n--- Gunakan format: ---\n\`${prefix+command} namafitur•••function•••casenya•••lib/script.json,,,isi file\`\n\n--- Contoh: ---\n*${prefix+command} halo•••async function halo() {\nreturn m.reply('halo')\n}•••case 'halo':{\nawait halo()\n}\nbreak;•••lib/halo.json,,,["halo"]*`);

    const [name, functionCode, caseCode, upFileRaw] = args.map(a => a.trim());

    // Memeriksa apakah file casefitur.json ada
    const casefiturPath = './lib/casefitur.json';
    let icasefitur = [];

    if (fs.existsSync(casefiturPath)) {
        try {
            icasefitur = JSON.parse(fs.readFileSync(casefiturPath, 'utf-8'));
        } catch (error) {
            return rioo.reply('❌ Terjadi kesalahan saat membaca casefitur.json');
        }
    }

    // Cek apakah fitur sudah ada
    if (icasefitur.some(f => f.name === name)) {
        return rioo.reply(`⚠️ *Fitur "${name}" sudah ada dalam casefitur.json!*`);
    }

    // Jika function atau upFile kosong, biarkan tetap kosong
    const newFeature = {
        name: name,
        function: functionCode ? functionCode : " ", // Jika kosong, beri spasi
        casenya: caseCode ? caseCode.replace(/\\n/g, '\n') : ""
    };

    let upFile = [];

    // **Proses upFile jika ada**
    if (upFileRaw && upFileRaw.trim() !== '') {
        const [filePath, fileContent] = upFileRaw.split(',,,');
        if (filePath && fileContent) {
            try {
                // **Konversi isi file menjadi string JSON**
                let jsonString = JSON.stringify(JSON.parse(fileContent), null, 2);

                upFile.push({ [filePath]: jsonString });

                // **Menyimpan file ke path yang ditentukan**
                fs.writeFileSync(filePath, jsonString, 'utf-8');
            } catch (error) {
                return rioo.reply('❌ Terjadi kesalahan saat menyimpan upFile. Pastikan isi file dalam format JSON yang benar.');
            }
        }
    }

    // Tambahkan upFile jika ada
    if (upFile.length > 0) newFeature.upFile = upFile;

    // **Tambahkan ke casefitur.json**
    icasefitur.push(newFeature);

    // Simpan perubahan
    try {
        fs.writeFileSync(casefiturPath, JSON.stringify(icasefitur, null, 2), 'utf-8');
        rioo.reply(`✅ *Fitur "${name}" berhasil ditambahkan ke casefitur.json!*`);
    } catch (error) {
        rioo.reply('❌ Gagal menyimpan fitur baru ke casefitur.json');
    }
}
break;
case 'delfitur': {
    if (!isCreator) return rioo.reply("❗ Fitur Khusus Creator.");

    const fiturName = text.trim();
    if (!fiturName) return rioo.reply(`\n--- Gunakan format: ---\n\`${prefix+command} namafitur\`\n\n--- Contoh: ---\n*${prefix+command} halo*`);

    const icasefiturPath = './lib/casefitur.json';
    if (!fs.existsSync(icasefiturPath)) return rioo.reply('⚠️ File casefitur.json tidak ditemukan!');

    try {
        let icasefitur = JSON.parse(fs.readFileSync(icasefiturPath, 'utf-8'));

        // Cari fitur yang sesuai
        const fiturIndex = icasefitur.findIndex(f => f.name === fiturName);
        if (fiturIndex === -1) return rioo.reply(`⚠️ *Fitur "${fiturName}" tidak ditemukan dalam casefitur.json!*`);

        // Hapus fitur dari array
        icasefitur.splice(fiturIndex, 1);

        // Simpan kembali file casefitur.json
        fs.writeFileSync(icasefiturPath, JSON.stringify(icasefitur, null, 2), 'utf-8');
        rioo.reply(`✅ *Fitur "${fiturName}" berhasil dihapus dari casefitur.json!*`);
    } catch (error) {
        console.error(error);
        rioo.reply('❌ Terjadi kesalahan saat menghapus fitur dari casefitur.json');
    }
}
break;
case 'getcasesc': {
    if (!isCreator) return rioo.reply("❗Fitur Khusus Creator.");

    if (!text) return rioo.reply("❗ Gunakan format: .getcasesc <nama>");

    const casefiturPath = './lib/casefitur.json';

    // Periksa apakah file casefitur.json ada
    if (!fs.existsSync(casefiturPath)) {
        return rioo.reply("❌ File casefitur.json tidak ditemukan!");
    }

    try {
        const icasefitur = JSON.parse(fs.readFileSync(casefiturPath, 'utf-8'));
        const fitur = icasefitur.find(f => f.name.toLowerCase() === text.toLowerCase());

        if (!fitur) {
            return rioo.reply(`❌ Fitur "${text}" tidak ditemukan dalam casefitur.json!`);
        }

        // Ambil casenya
        let caseText = fitur.casenya || "❌ Case tidak ditemukan untuk fitur ini.";

        // Ubah kode case dari string JSON menjadi teks biasa
        caseText = caseText.replace(/\\n/g, '\n').replace(/\\"/g, '"');

rioo.reply(caseText);
    } catch (error) {
        console.error("❌ Error saat membaca casefitur.json:", error);
        return rioo.reply("❌ Terjadi kesalahan saat membaca casefitur.json.");
    }
}
break;
case 'listweb': {
if (!isCreator) return rioo.reply('Fitur Khusus Creator');
  const headers = {
    Authorization: `Bearer ${vercelToken}`
  }

  const res = await fetch('https://api.vercel.com/v9/projects', { headers })
  const data = await res.json()

  if (!data.projects || data.projects.length === 0) return rioo.reply('Tidak ada website yang ditemukan.')

  let teks = '🌐 Daftar Website Anda:\n\n'
  for (let proj of data.projects) {
    teks += `• ${proj.name} → ${proj.name}.vercel.app\n`
  }

  rioo.reply(teks)
}
break
case 'delweb': {
if (!isCreator) return rioo.reply('Fitur Khusus Creator');
  if (!text) return rioo.reply('Penggunaan: .delweb <namaWeb>')
  const webName = text.trim().toLowerCase()

  const headers = {
    Authorization: `Bearer ${vercelToken}`
  }

  try {
    const response = await fetch(`https://api.vercel.com/v9/projects/${webName}`, {
      method: 'DELETE',
      headers
    })

    if (response.status === 200 || response.status === 204) {
      return rioo.reply(`✅ Website ${webName} berhasil dihapus dari Vercel.`)
    } else if (response.status === 404) {
      return rioo.reply(`⚠️ Website ${webName} tidak ditemukan di akun Vercel kamu.`)
    } else if (response.status === 403 || response.status === 401) {
      return rioo.reply(`⛔ Token Vercel tidak valid atau tidak punya akses ke project ini.`)
    } else {
      let result = {}
      try {
        result = await response.json()
      } catch (e) {}
      return rioo.reply(`❌ Gagal menghapus website:\n${result.error?.message || 'Tidak diketahui'}`)
    }

  } catch (err) {
    console.error(err)
    rioo.reply(`Terjadi kesalahan saat mencoba menghapus:\n${err.message}`)
  }
}
break
case 'listprem': {
    if (!isCreator) return reply(mess.owner);

    let premList = Object.keys(db.data.users).filter(user => db.data.users[user].premium);

    if (premList.length === 0) {
        return rioo.reply("🚩 Tidak ada pengguna premium saat ini.");
    }

    let now = new Date().getTime();
    let msg = "• LIST PENGGUNA PREMIUM •\n\n";

    premList.forEach((user, index) => {
        let premiumDate = db.data.users[user].premiumDate || 0; 
        let expiry, remainingTime;

        if (premiumDate === Infinity) {
            expiry = "Unlimited";
            remainingTime = "∞";
        } else if (premiumDate > now) {
            expiry = formatDateTime(premiumDate);
            remainingTime = msToDate(premiumDate - now);
        } else {
            db.data.users[user].premium = false;
            db.data.users[user].premiumDate = 0;
            return; 
        }

        msg += `${index + 1}. ${user}\n   📅 Expired: ${expiry}\n   ⏳ Sisa: ${remainingTime}\n\n`;
    });

    if (!msg.includes("📅 Expired")) {
        return rioo.reply("🚩 Tidak ada pengguna premium yang aktif saat ini.");
    }

    rioo.reply(msg);
}
break;
case 'addprem': {
    if (!isCreator) return reply(mess.owner);
    if (!text) {
        return rioo.reply(`• Example : /addprem idtele|1`);
    }

    var hl = text.split('|');
    var userId = no(hl[0]); 
    var daysToAdd = parseInt(hl[1]); 

    if (!db.data.users[userId]) {
        return rioo.reply('🚩 Pengguna tidak ada dalam database');
    }

    var now = new Date().getTime();
    var jumlahHari = 86400000 * daysToAdd; 

    if (isNaN(jumlahHari)) {
        db.data.users[userId].premium = true;
        db.data.users[userId].premiumDate = Infinity;
    } else {
        db.data.users[userId].premium = true;
        if (db.data.users[userId].premiumDate && db.data.users[userId].premiumDate > now) {
            db.data.users[userId].premiumDate += jumlahHari;
        } else {
            db.data.users[userId].premiumDate = now + jumlahHari;
        }
    }

    let premiumDate = db.data.users[userId].premiumDate === Infinity 
        ? "Unlimited" 
        : msToDate(db.data.users[userId].premiumDate - now);

    rioo.reply(`• UPGRADE PREMIUM\n\nBerhasil menambahkan akses premium kepada ${userId} selama ${daysToAdd} hari.\n\nPremium : ${premiumDate}`);
}
break;
case 'speed': case 'ping':{
const used = process.memoryUsage();
const cpus = os.cpus().map(cpu => {
                    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			        return cpu
                })
                const cpu = cpus.reduce((last, cpu, _, { length }) => {
                    last.total += cpu.total
                    last.speed += cpu.speed / length
                    last.times.user += cpu.times.user
                    last.times.nice += cpu.times.nice
                    last.times.sys += cpu.times.sys
                    last.times.idle += cpu.times.idle
                    last.times.irq += cpu.times.irq
                    return last
                }, {
                    speed: 0,
                    total: 0,
                    times: {
			            user: 0,
			            nice: 0,
			            sys: 0,
			            idle: 0,
			            irq: 0
                }
                })
let timestamp = speed();
let latensi = speed() - timestamp;
let neww = performance.now();
let tio = await nou.os.oos();
let oldd = performance.now();
var tot = await nou.drive.info();
let respon = `${pj}JARINGAN SERVER${pj}
- Ping: ${latensi.toFixed(4)} _Second_ 

${pj}INFO SERVER${pj}
- OS: ${tio}
- IP Address: ${nou.os.ip()}
- Type OS: ${nou.os.type()}

${pj}RAM :${pj}
- Total: ${formatp(os.totalmem())}
- Digunakan: ${formatp(os.totalmem() - os.freemem())}

${pj}PENYIMPANAN :${pj}
- Total: ${tot.totalGb} GB
- Digunakan: ${tot.usedGb} GB (${tot.usedPercentage}%)
- Tersedia: ${tot.freeGb} GB (${tot.freePercentage}%)

${pj}RUNTIME SERVER${pj}
Aktif:
${runtime(process.uptime())}`.trim();
rioo.replyWithPhoto({
            url: global.pp,
        }, {
            caption: respon
        });
}
break
case 'createweb':
case 'cweb': {
  if (!isCreator) return rioo.reply('khusus Creator.')
  if (!text) return rioo.reply('Penggunaan: .createweb <namaWeb>')

  const isQuotedDocument = !!rioo.message?.reply_to_message?.document
  if (!isQuotedDocument) return rioo.reply('Reply dokumen HTML.')

  const quotedMessage = rioo.message?.reply_to_message
  const mime = quotedMessage?.document?.mime_type || ''
  const fileName = quotedMessage?.document?.file_name || 'index.html'
  if (!mime.includes('html') && !fileName.endsWith('.html')) return rioo.reply('File harus berupa HTML (.html)')

  const webName = text.trim().toLowerCase().replace(/[^a-z0-9-_]/g, '')
  const domainCheckUrl = `https://${webName}.vercel.app`

  // Cek apakah domain sudah terpakai
  try {
    const check = await fetch(domainCheckUrl)
    if (check.status === 200) {
      return m.reply(`❌ Nama web *${webName}* sudah digunakan. Silakan gunakan nama lain.`)
    }
  } catch (e) {
    // Tidak ada website aktif — aman untuk digunakan
  }
  if (webName.length < 3) return rioo.reply('Nama web terlalu pendek. Gunakan minimal 3 karakter.')

  try {
    const media = await downloadMediaMessage(rioo)
    const htmlContent = media.toString()

    const headers = {
      Authorization: `Bearer ${vercelToken}`,
      'Content-Type': 'application/json'
    }

    // Buat project di Vercel (abaikan error jika sudah ada)
    await fetch('https://api.vercel.com/v9/projects', {
      method: 'POST',
      headers,
      body: JSON.stringify({ name: webName })
    }).catch(() => {})

    // Deploy file HTML
    const deploy = await fetch('https://api.vercel.com/v13/deployments', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        name: webName,
        project: webName,
        files: [
          {
            file: 'index.html',
            data: Buffer.from(htmlContent).toString('base64'),
            encoding: 'base64'
          }
        ],
        projectSettings: { framework: null }
      })
    })

    const res = await deploy.json()
    if (!res || !res.url) {
      console.log('Deploy error:', res)
      return rioo.reply(`Gagal deploy ke Vercel:\n${JSON.stringify(res)}`)
    }

    rioo.reply(`✅ Website berhasil dibuat!\n\n🌐 URL: https://${webName}.vercel.app`)
  } catch (err) {
    console.error(err)
    rioo.reply('Terjadi kesalahan saat membuat website.')
  }
}
break
case 'createscript':
case 'createsc': {
  try {
    const pathReg = './database/register.json'
    let dataReg = fs.existsSync(pathReg) ? JSON.parse(fs.readFileSync(pathReg)) : []

    const theuser_id = rioo.message.from.id.toString().trim();

    let isRegistered = dataReg.some(user => user['id'] === theuser_id);
    let userData = dataReg.find(user => user['id'] === theuser_id);
    let userWa = userData ? userData['wa'] : '6285659202292';

    let tuttks = `\n--- Gunakan format: ---\n/createsc <namaBot>|<namaOwner>|<fitur1>,<fitur2>,...\n\n--- Contoh : ---\n/createsc ErizaBot|ErizaOffc|brat,qc,play,pinterest\n\nKetik /listfitur untuk melihat fitur tersedia.`

    let isFreeUser = !userData || !isRegistered;

    if (!text) {
      return rioo.replyWithPhoto({
        url: 'https://files.catbox.moe/zxxjwq.jpg',
      }, {
        caption: tuttks,
        parse_mode: 'Markdown',
        reply_markup: {
          remove_keyboard: true
        }
      });
    }

    const mycfitur = require('./lib/casefitur.json');
    const [namaBot, namaOwner, fiturInput] = text.split('|');

    if (!namaBot || !namaOwner || !fiturInput) {
      return rioo.replyWithPhoto({
        url: 'https://files.catbox.moe/zxxjwq.jpg',
      }, {
        caption: 'Format salah. Contoh:\n/createsc Botku|Namaku|brat,qc,play'
      });
    }

    // Cek validasi jika bukan user terdaftar
    let features;
    if (fiturInput.toLowerCase() === 'allfitur') {
      if (isFreeUser) {
        return rioo.reply('❌ Pengguna gratis tidak diizinkan menggunakan opsi "allfitur".\nSilakan beli ke /owner untuk akses penuh.');
      }
      features = mycfitur.map(f => f.name);
    } else {
      features = fiturInput.split(',').map(f => f.trim());

      if (isFreeUser && features.length > 10) {
        return rioo.reply(`❌ Pengguna gratis hanya boleh maksimal 10 fitur.\nKamu memasukkan ${features.length} fitur.`);
      }
    }

    let AdmZip = require('adm-zip');

    // Gunakan file base script lokal
    const tempZipPath = './temp/disini.zip';
    if (!fs.existsSync(tempZipPath)) {
      return rioo.reply('File base script tidak ditemukan di ./temp/disini.zip');
    }

    let zip = new AdmZip(tempZipPath);
    let extractPath = `./temp/extracted_${pushname}`;
    zip.extractAllTo(extractPath, true);

    const caseFilePath = `${extractPath}/case.js`;
    let caseContent = fs.readFileSync(caseFilePath, 'utf-8');
    let newFunctions = '';

    const validFeatures = [];

    rioo.reply(`💾 Menambah Fitur:\n\n${features.join('\n')}\n\nke case.js ..`);

    for (let i = 0; i < features.length; i++) {
      let feature = features[i].trim();
      let featureData = mycfitur.find(f => f.name === feature);

      if (!featureData) {
        rioo.reply(`⚠️ *Fitur "${feature}" tidak ditemukan!*`);
        continue;
      }

      if (!newFunctions.includes(featureData.function) && !caseContent.includes(featureData.function)) {
        newFunctions += `${featureData.function}\n`;
      }

      if (!caseContent.includes(featureData.casenya)) {
        caseContent = caseContent.replace(
          'switch (command) {',
          `${featureData.function}
switch (command) {
${featureData.casenya}`
        );
      }

      if (featureData.upFile && featureData.upFile.length > 0) {
        featureData.upFile.forEach(file => {
          const filePath = Object.keys(file)[0];
          const fileContent = file[filePath];

          const fileDirectory = path.join(extractPath, filePath);
          const dirPath = path.dirname(fileDirectory);
          if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
          }

          fs.writeFileSync(fileDirectory, fileContent, 'utf-8');
        });
      }

      validFeatures.push(feature);
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    fs.writeFileSync(caseFilePath, caseContent, 'utf-8');

    // Ubah settings.js hanya untuk owner dan bot name, hapus versi dan password
    const settingsFilePath = `${extractPath}/settings.js`;
    let settingsContent = fs.readFileSync(settingsFilePath, 'utf-8');
    let newSettingsContent = settingsContent
      .replace(/global.owner = .*/g, `global.owner = "${userWa}";`)
      .replace(/global.namabot = .*/g, `global.namabot = '${namaBot}';`)
      .replace(/global.ownername = .*/g, `global.ownername = '${namaOwner}';`);
    fs.writeFileSync(settingsFilePath, newSettingsContent, 'utf-8');

    // Update owner.json
    const ownerFilePath = `${extractPath}/database/owner.json`;
    fs.writeFileSync(ownerFilePath, JSON.stringify([userWa]), 'utf-8');

    // Update listmenu.json dengan fitur valid
    const listMenuPath = `${extractPath}/lib/listmenu.json`;
    let listMenu = fs.existsSync(listMenuPath) ? JSON.parse(fs.readFileSync(listMenuPath)) : ["addprem", "delprem", "ping", "public", "self", "owner"];

    validFeatures.forEach(feature => {
      if (!listMenu.includes(feature)) {
        listMenu.push(feature);
      }
    });

    fs.writeFileSync(listMenuPath, JSON.stringify(listMenu, null, 2), 'utf-8');

    // Buat ZIP baru
    let newZip = new AdmZip();
    newZip.addLocalFolder(extractPath);
    let outputZipPath = `./temp/sc_${pushname}.zip`;
    newZip.writeZip(outputZipPath);

    let updatedScriptData = fs.readFileSync(outputZipPath);

    if (validFeatures.length === 0) {
      return rioo.reply("❌ Tidak ada fitur yang valid!");
    }

    await rioo.replyWithDocument(
      {
        source: updatedScriptData,
        filename: `SC-${namaBot}.zip`
      },
      {
        caption: `✅ Berhasil dibuat!\n\n𝗡𝗮𝗺𝗮 𝗕𝗼𝘁: ${namaBot}\n𝗢𝘄𝗻𝗲𝗿: ${namaOwner}\n𝗙𝗶𝘁𝘂𝗿: ${validFeatures.join(', ')}\n\nMau Rename? https://eriza-renamesc.vercel.app`
      }
    );

    // Bersihkan temporary folder dan file zip
    fs.rmSync(extractPath, { recursive: true, force: true });
    fs.unlinkSync(outputZipPath);

  } catch (err) {
    console.error(err);
    rioo.reply(`Terjadi kesalahan: ${err.message}`);
  }
};
break;

case 'regist':
case 'add': {
  try {
    if (!isCreator) return rioo.reply('Kamu Siapa?!')
    if (!text.includes('|')) return rioo.reply('Format salah!\nContoh: .add 123456789|6281234567890');

    const [idTelegram, nomorWA] = text.split('|').map(a => a.trim());

    if (!idTelegram || !nomorWA) {
      return rioo.reply('ID Telegram dan Nomor WhatsApp tidak boleh kosong!');
    }

    const pathReg = './database/register.json';
    const dataReg = fs.existsSync(pathReg) ? JSON.parse(fs.readFileSync(pathReg)) : [];

    const index = dataReg.findIndex(u => u.id === idTelegram || u.wa === nomorWA);

    if (index !== -1) {
      // Update data jika sudah ada
      dataReg[index] = { id: idTelegram, wa: nomorWA };
      rioo.reply(`🔁 Data berhasil diperbarui!\n\nID Telegram: ${idTelegram}\nNomor WA: ${nomorWA}`);
    } else {
      // Tambah data baru
      dataReg.push({ id: idTelegram, wa: nomorWA });
      rioo.reply(`✅ Berhasil Add Akses!\n\nID Telegram: ${idTelegram}\nNomor WA: ${nomorWA}`);
    }

    fs.writeFileSync(pathReg, JSON.stringify(dataReg, null, 2));
  } catch (err) {
    console.error(err);
    rioo.reply('Terjadi kesalahan saat mendaftar.');
  }
}
break;
case 'listfitur':
case 'listfitursc': {
    
    let filePath = './lib/casefitur.json';

    if (!fs.existsSync(filePath)) {
        return rioo.reply('❌ File casefitur.json tidak ditemukan!');
    }

    try {
        let rawData = fs.readFileSync(filePath);
        let fiturList = JSON.parse(rawData);

        if (!Array.isArray(fiturList) || fiturList.length === 0) {
            return rioo.reply('⚠️ Tidak ada fitur yang tersedia.');
        }

        let fiturNames = fiturList.map(f => `<╺ > ┃  ${f.name}`).join('\n');
        let message = `💬 Daftar Fitur yang Tersedia:\n[ Total Fitur = ${fiturList.length} ]\n\n${fiturNames}`;

        rioo.reply(message);
    } catch (error) {
        console.error(error);
        rioo.reply('❌ Terjadi kesalahan saat membaca daftar fitur.');
    }
}
break;
case 'scase':
case 'sfitur':
case 'statuscase':
case 'statusfitur': {
    try {
    	if (!isCreator) return rioo.reply("❗ *Access Denied*\nFitur Only `Owner`")
        const caseName = text.split(' ')[0]; // Mengambil nama case atau fitur yang dicari
        if (!caseName) return rioo.reply('❌ Silakan masukkan nama case atau fitur yang ingin dicari.');
        const caseFilePath = './case.js'; // Sesuaikan dengan lokasi file case.js
        let caseFileContent = fs.readFileSync(caseFilePath, 'utf8');
        let caseLines = caseFileContent.split('\n');
        // Regex untuk mencari case "nama" atau case 'nama'
        let caseRegex = /^\s*case\s+["']([^"']+)["']\s*:/;
        let caseFound = null;
        // Loop untuk mencari case yang sesuai
        for (let i = 0; i < caseLines.length; i++) {
            let match = caseLines[i].match(caseRegex);
            if (match && match[1] === caseName) {
                // Jika case ditemukan
                caseFound = {
                    name: match[1],
                    start: i + 1,
                    end: null,
                };
            }
            // Jika menemukan break; maka case selesai
            if (/^\s*break\s*/.test(caseLines[i]) && caseFound) {
                caseFound.end = i + 1;
                break;
            }
        }
        if (!caseFound) {
            return m.reply(`❌ Case atau fitur *${caseName}* tidak ditemukan.`);
        }
        // Menampilkan status case
        let statusMessage = `
🔍 Status Case/Fitur:
- Nama Case: ${caseFound.name}
- Baris: ${caseFound.start} - ${caseFound.end || '??'}
`;
        rioo.reply(statusMessage);
    } catch (error) {
        console.error('❌ Error saat mencari case:', error);
        rioo.reply('⚠️ Terjadi kesalahan saat mencari status case.');
    }
}
break;
case 'totalfitur': {
reply(`${totalFitur()} Feature`)
}
break
case 'orkut-search': {
    try {
        if (!text) {
            return rioo.reply('Example: indosat');
        }

        const response = await searchProduct(text);

        if (!response || !response.length) {
            return rioo.reply('Tidak ada hasil yang ditemukan.');
        }

        let resultText = `🔍 *Hasil Pencarian*\n\n❓ *Query* : ${text}\n🛍️ *Total Hasil* : ${response.length}\n\n`;

        for (let i = 0; i < response.length; i++) {
            const product = response[i];
            resultText += `🆔 *Kode Produk* : ${product.kode}\n`;
            resultText += `📝 *Keterangan* : ${product.keterangan}\n`;
            resultText += `🛒 *Produk* : ${product.produk}\n`;
            resultText += `🏷️ *Kategori* : ${product.kategori}\n`;
            resultText += `💰 *Harga* : Rp ${Func.formatNumber(parseInt(product.harga))}\n`;
            resultText += `🟢 *Status* : ${product.status === '1' ? 'Aktif ✅' : 'Nonaktif ❎'}\n`;
            resultText += `──────────────────────\n\n`;
        }
        const fileName = `search_result_${Date.now()}.txt`;
        const filePath = `./${fileName}`;
        require('fs').writeFileSync(filePath, resultText);
        await rioo.replyWithDocument({ source: filePath }, { caption: "📄 Hasil Pencarian Produk" });
        require('fs').unlinkSync(filePath);

    } catch (e) {
        console.error(e);
        rioo.reply('Terjadi kesalahan dalam pencarian.');
    }
};
break;
case 'mutasiqris': {
    if (!isCreator) return reply(mess.owner);
    try {
        const id = global.ord_id;
        const apikey = global.ord_apikey;
        const apiUrl = `https://www.gateway.okeconnect.com/api/mutasi/qris/${id}/${apikey}`;

        const requestOptions = {
            method: 'GET',
            redirect: 'follow'
        };

        const response = await fetch(apiUrl, requestOptions);
        const result = await response.json();

        if (result.status !== 'success') {
            return reply('Terjadi kesalahan saat mengambil data.');
        }

        const data = result.data;
        let message = '🔴 ORDERKUOTA DEPO MUTASI\n\n';

        if (data.length === 0) {
            message += 'Tidak ada data mutasi.';
        } else {
            data.forEach(entry => {
                message += `📅 *Date* : ${entry.date}\n`;
                message += `💰 *Amount* : Rp ${Func.formatNumber(parseInt(entry.amount))}\n`;
                message += `📌 *Type* : ${entry.type}\n`;
                message += `🏦 *QRIS* : ${entry.qris}\n`;
                message += `🏷️ *Brand Name* : ${entry.brand_name}\n`;
                message += `🔖 *Issuer Reff* : ${entry.issuer_reff}\n`;
                message += `🆔 *Buyer Reff* : ${entry.buyer_reff}\n`;
                message += `💳 *Balance* : Rp ${Func.formatNumber(parseInt(entry.balance))}\n`;
                message += `──────────────────────\n\n`;
            });
        }
        const fileName = `mutasi_qris_${Date.now()}.txt`;
        const filePath = `./${fileName}`;
        require('fs').writeFileSync(filePath, message);
        await rioo.replyWithDocument({ source: filePath }, { caption: "📄 Mutasi QRIS Terbaru" });

        require('fs').unlinkSync(filePath);

    } catch (e) {
        console.error(e);
        await reply(`🚩 ${e}`);
    }
};
break;
case 'orkutsaldo':{
try {
if (!isCreator) return reply(mess.owner)
         const web = global.ord_web;
         const id = global.ord_id;
         const pin = global.ord_pin;
         const psswd = global.ord_password;
         const apiUrl = `${web}/trx/balance?memberID=${id}&pin=${pin}&password=${psswd}`;

         const requestOptions = {
            method: 'GET',
            redirect: 'follow'
         };

         const response = await fetch(apiUrl, requestOptions);
         const result = await response.text();

         await reply(result);
      } catch (e) {
         console.error(e);
         await reply(global.status.error);
      }
};
break
case 'orkut-beli':{
try {
let user = global.db.data.users;
	let users = user[sender];
      const [code_product, dest] = text.split('|');

      if (!code_product || !dest) {
        return reply(`Format yang Anda masukkan salah. Silakan gunakan format yang benar.

• *Example* : 
${prefix + command} code_produk|nomor_tujuan
${prefix + command} S5|082280004280`);
      }
      const productCode = code_product
      users.code_product = code_product;
      users.dest = dest;
      const hargaID = global.ord_harga_id;
      const response = await fetch(`https://www.okeconnect.com/harga/json?id=${hargaID}`);
         const data = await response.json();

         if (!data || data.length === 0) {
            return reply('Data produk tidak ditemukan.');
         }

         const product = data.find(prod => prod.kode === productCode);
         users.produk = product;
         users.pembelian = true;
         users.proses_beli = true;

         if (!product) {
            return reply('Produk dengan kode tersebut tidak ditemukan.');
         }
         const number = sender;
         const saldo = await db.data.users[number].saldo;
         const Sproduk = users.produk;
         const code_produk = users.code_product;
         let hrga = parseInt(Sproduk.harga);
         let total = hrga;
         let selisih = total - saldo;

         if (total > saldo) return reply(`🚩 Saldo kamu tidak mencukupi, Saldo kamu kurang *Rp. ${Func.formatNumber(selisih)}*`)
         let total_refID = await getTotalRefID();
         total_refID++;
         const refID = total_refID.toString();
         await addTransaction(code_produk, dest, refID, number, total);

         reply('Transaksi berhasil ditambahkan.');
      
      const memberID = global.ord_id;
      const pin = global.ord_pin;
      const password = global.ord_password;
      
      const signature = generateSignature(memberID, Sproduk, dest, refID, pin, password);

      const url = `https://h2h.okeconnect.com/trx?memberID=${memberID}&pin=${pin}&password=${password}&product=${code_produk}&dest=${dest}&refID=${refID}&sign=${signature}`;

const response2 = await fetch(url);
const result = await response2.text();
const [, idTransaksi] = /R#(\d+)/.exec(result) || [];
const [, idTransaksiGlobal] = /T#(\d+)/.exec(result) || [];
const [, keterangan] = /([^,]+)/.exec(result) || [];
const [, jamOrder] = /@(\d+:\d+)/.exec(result) || [];

let processedResult = `*🛍️  P R O S E S*

🆔ID Transaksi : *${idTransaksi}*
🌐ID Transaksi Global : *${idTransaksiGlobal || '-'}*
🕘Jam Order : *${jamOrder}*

${keterangan}

${global.OWNER_NAME}`;
reply(processedResult);
         users.saldo -= total;
         users.total_pembelian += 1;
         users.total_pengeluaran += total;
         users.proses_beli = false;
         users.pembelian = false;
         users.code_product = '';
         users.dest = '';
         users.produk = '';

         reply(`Saldo berhasil dikurangi. Sisa Saldo Anda: Rp. ${Func.formatNumber(users.saldo)}`);
    } catch (e) {
      return reply(e);
    }
};
break
case 'orderkuota-deposit': {
    if (!text) return reply('❌ Masukkan nominal deposit. Contoh: .orderkuota-deposit 10000' );

    const amount = parseInt(text.trim());
    if (isNaN(amount) || amount <= 0) {
        return reply('🚫 Nominal tidak valid. Pastikan hanya angka positif, contoh: .orderkuota-deposit 100');
    }

    const fee = Math.floor(Math.random() * 101);
    const totalAmount = amount + fee; 

    try {
        const paymentResponse = await fetch(`https://api.botwa.riooxdzz.me/api/orkut/createpayment?amount=${totalAmount}&codeqr=${qrisOrderKuota}&apikey=${riiapikey}`);
        const paymentData = await paymentResponse.json();

        if (!paymentData.result || !paymentData.result.qrImageUrl.url) {
            throw new Error('Gagal membuat pembayaran, coba lagi nanti.');
        }

        const expirationTime = new Date(Date.now() + 5 * 60 * 1000);
        const formattedExpiration = expirationTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

        const paymentDetails = `DETAIL PEMBAYARAN\n\nID Transaksi: ${paymentData.result.transactionId}\nJumlah Deposit: Rp ${amount.toLocaleString('id-ID')}\nBiaya Admin: Rp ${fee.toLocaleString('id-ID')}\nTotal Pembayaran: Rp ${totalAmount.toLocaleString('id-ID')}\nBatas Waktu Pembayaran: 5 Menit\n\nSilakan scan QRIS di atas untuk melanjutkan pembayaran`;
        
        let sentMessage = await rioo.replyWithPhoto({
            url: paymentData.result.qrImageUrl.url,
        }, {
            caption: paymentDetails
        });

        const statusApiUrl = `https://api.botwa.riooxdzz.me/api/orkut/cekstatus?merchant=${ord_id}&keyorkut=${ord_apikey}&apikey=${riiapikey}`;
        let isTransactionComplete = false;
        const maxWaitTime = 5 * 60 * 1000; // 5 minutes
        const startTime = Date.now();

        while (!isTransactionComplete && Date.now() - startTime < maxWaitTime) {
            try {
                const statusResponse = await axios.get(statusApiUrl);
                const statusData = statusResponse.data;

                if (statusData && statusData.amount && parseInt(statusData.amount) === totalAmount) {
                    isTransactionComplete = true;
                    global.db.data.users[sender].saldo += amount;

                    const successNotification = `✅ PEMBAYARAN BERHASIL!\n\nIDTransaksi:${paymentData.result.transactionId}\nJumlahDitambahkan: Rp ${amount.toLocaleString('id-ID')}\nSaldoAnda: Rp ${global.db.data.users[sender].saldo.toLocaleString('id-ID')}\n\nTerima kasih telah melakukan deposit!`;
                    await reply(successNotification);
                    return;
                }
            } catch (error) {
                console.error('Error memeriksa status transaksi:', error);
            }

            await new Promise(resolve => setTimeout(resolve, 10000));
        }
        
        if (!isTransactionComplete) {

            const expiredText = `❌ *WAKTU PEMBAYARAN TELAH HABIS!*\n\nTransaksi Anda melebihi batas waktu pembayaran. Silakan coba lagi dengan membuat transaksi baru.`;
            await rioo.reply(expiredText);
        }
    } catch (error) {
        console.error('Error membuat atau memeriksa pembayaran:', error);
        return rioo.reply('❌ Gagal membuat atau memeriksa pembayaran. Silakan coba lagi nanti.');
    }
}
break;
case 'blackboxai': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/blackboxai?content=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'deepseek': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/deepseek-llm-67b-chat?content=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'esia': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/esia?content=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'gemini': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/gemini-pro?content=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'llama': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/llama?prompt=You%20are%20an%20assistant%20that%20always%20responds%20in%20Indonesian%20with%20a%20friendly%20and%20informal%20tone&message=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'luminai': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/luminai?content=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'meta': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/metaai?query=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'muslimai': {
if (!text) {
return rioo.reply('Please enter question for Ai');
}
let aiFetch = await fetch(`https://api.siputzx.my.id/api/ai/muslimai?query=${encodeURIComponent(text)}`)
let aiJson = await aiFetch.json()
let aiAnswer = aiJson.data;
rioo.reply(aiAnswer);
}
break
case 'owner':
case 'creator': {
await rioo.sendContact(OWNER_NUMBER, OWNER_NAME)
reply(`Itu Owner Saya [${OWNER_NAME}](${OWNER[0]})`)
}
break
case 'runtime':{
    rioo.deleteMessage().catch(() => {});
      reply(`Bot Online ${runtime(process.uptime())}`)
    }
  break
case 'tqto': {
    const makasih = `━━ ⬢ 𝗧𝗵𝗮𝗻𝗸𝘀 𝗧𝗼 ⬢ ━━

⫎ 𝐒𝐜𝐫𝐢𝐩𝐭 𝐓𝐞𝐚𝐦 ━━━
╰⩺ ʀɪᴏᴏ
╰⩺ ʀᴜᴢᴜʀᴇɴx
╰⩺ ᴋɪᴜʀʀ
╰⩺ ᴛᴀᴍᴀ
╰⩺ ɢʜᴏsᴛxᴅᴢᴢ
╰⩺ ᴛᴇᴀᴍ ғʟᴇx ᴀɢᴇɴᴄʏ

⫎ 𝐍𝐞𝐱𝐭 𝐓𝐞𝐚𝐦 ━━━━
╰⩺ ᴇʀɪᴢᴀ ᴏғғɪᴄɪᴀʟ
╰⩺ ᴄʜᴀᴛɢᴘᴛ
╰⩺ ᴍʏ sᴜᴘᴘᴏʀᴛᴇʀ

━━━━━━━━━━━━━━━`;
    rioo.reply(makasih);
}
break;
default:
let user = global.db.data.users[sender]                              
    if (user.premiumTime > 0 && new Date() - user.premiumTime > 0) {
    await rioo.reply(`waktu premium kamu sudah habis!`)
            user.premiumTime = 0
            user.premium = false
        }
if (budy.startsWith('>')) {
if (!isCreator) return reply(mess.owner);
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await rioo.reply(evaled);
} catch (err) {
rioo.reply(String(err));
}
}
        if (budy.startsWith('=>')) {
if (!isCreator) return reply(mess.owner)
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return rioo.reply(bang)
}
try {
let util = require("util")
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
rioo.reply(String(e))
}
}
        
if (budy.startsWith('$')) {
    if (!isCreator) return reply(mess.owner)
    exec(budy.slice(2), (err, stdout) => {
        if (err) return rioo.reply(`${err}`)
        if (stdout) return rioo.reply(stdout)
    })
}
}
} catch (err) {
const util = require('util');
console.log(util.format(err));

}
};
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
