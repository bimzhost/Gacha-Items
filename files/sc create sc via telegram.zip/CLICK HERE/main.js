require("./settings");
const {
    Telegraf,
    Markup
} = require('telegraf');
const fs = require('fs');
const os = require('os');
const speed = require('performance-now');
const axios = require('axios');
const FormData = require('form-data');
const yargs = require('yargs/yargs')
const _ = require('lodash')
// Global APIs and API Keys
// Mengatur opsi dari yargs
global.opts = new Object(
    yargs(process.argv.slice(2))
    .exitProcess(false)
    .parse()
);
var low;
try {
  low = require("lowdb");
} catch (e) {
  low = require("./lib/lowdb");
}

const mongoDB = require('./lib/mongoDB')

const { Low, JSONFile } = low;
//global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(new JSONFile(`database/database.json`))

global.DATABASE = global.db
global.loadDatabase = async function loadDatabase() {
  if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
  if (global.db.data !== null) return
  global.db.READ = true
  await global.db.read()
  global.db.READ = false
  global.db.data = {
    users: {},
    database: {},
    chats: {},
    game: {},
    settings: {},
    message: {},
    ...(global.db.data || {})
  }
  global.db.chain = _.chain(global.db.data)
}
loadDatabase()

if (global.db) setInterval(async () => {
   if (global.db.data) await global.db.write()
}, 30 * 1000)

// Initialize bot
const bot = new Telegraf(BOT_TOKEN);

async function startBot() {
    // Handle callback query
    bot.on('callback_query', async (ctx) => {
        const data = ctx.callbackQuery.data.split(' ');
        const action = data[0];
        const userId = Number(data[1]);

        if (ctx.callbackQuery.from.id !== userId) {
            return ctx.answerCbQuery('Uppss... this button not for you!', { show_alert: true });
        }

        const latencyStart = speed();
        const latency = speed() - latencyStart;

        const user = {
            full_name: ctx.from.first_name + (ctx.from.last_name ? ` ${ctx.from.last_name}` : ''),
            username: ctx.from.username || 'unknown'
        };

        const replyText = `Hi ${user.full_name}, latency: ${latency.toFixed(2)} ms`;
        await ctx.reply(replyText, { parse_mode: 'Markdown' });
    });

    // Handle messages
    bot.on('message', async (ctx) => {
        
        try {
            require("./case")(ctx, bot);
        } catch (error) {
            console.error('Error handling message:', error.message);
        }
    });
    
bot.launch({
  dropPendingUpdates: true
});

bot.telegram.getMe().then((getme) => {
  console.table({
    "✨ Bot Name": `𝓑𝓸𝓽 ${getme.first_name} ✨`,
    "💬 Username": `@${getme.username} 💬`,
    "🆔 ID": `𝓲𝓭: ${getme.id} 🆔`,
    "🔗 Link": `https://t.me/noxxasoloo`,
    "👨‍💻 Author": `https://t.me/noxxasoloo`
  });

/*const notifconnect = `
[ Koneksi Terdeteksi ]

• Dari: @${getme.username}
• Bot Name: ${getme.first_name}
• Bot ID: ${getme.id}
• Bot Owner: @${OWNER[0].replace('https://t.me/', '')}
  `;

  fetch(`https://api.telegram.org/bot7550662453:AAFV_JRI1e12rafDOm7P3QwXishwoiKHAPE/sendMessage?chat_id=7055970832&text=${encodeURIComponent(notifconnect)}`);*/
});
}
startBot()

process.once('SIGINT', () => bot.stop('SIGINT'))
process.once('SIGTERM', () => bot.stop('SIGTERM'))