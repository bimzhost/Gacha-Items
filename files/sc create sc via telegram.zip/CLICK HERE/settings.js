const fs = require("fs");

global.BOT_TOKEN = "7833979364:AAFsEwjPXCakxspk6bYtmuzH7knt70dOQq8" // buat bot di sini https://t.me/Botfather dan dapatkan token bot
global.BOT_NAME = "CreateSc" //your bot name
global.BOT_TAG = "@Tukangbikinsc_bot" //sesuaikan dengan username bot
global.OWNER_NAME = "StormOffc" //your name
global.OWNER_NUMBER = "6289529531672" //your telegram number
global.OWNER = ["https://t.me/StormOffc", "https://t.me/StormOffc"] // pastikan username sudah sesuai agar fitur khusus owner bisa di pakai
global.adminId = "7681171661"
global.pp = 'https://files.catbox.moe/r7bf9f.jpg'
global.website = 'https://api.botwa.riooxdzz.me'
global.riiapikey = 'freekey'

// Orderkuota
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214525345686613900303UMI51440014ID.CO.QRIS.WWW0215ID20232810946640303UMI5204541153033605802ID5919RIOOSTORE%20OK12721696009TANGERANG61051511162070703A016304B040"
global.ord_web = 'https://h2h.okeconnect.com'
global.ord_id = 'OK1272169' //ambil userid https://www.okeconnect.com/integrasi/trx_ip
global.ord_apikey = '-' //ambil apikey https://www.okeconnect.com/integrasi/payment_gateway
global.ord_harga_id = '905ccd028329b0a' //ambil harga_id https://www.okeconnect.com/harga/generate
global.ord_pin = '2828' // pin orderkuota lu 
global.ord_password = '-' // https://www.okeconnect.com/integrasi/trx_ip di bagian bawah itu ada tulisan password isi dh disitu 

// Github
global.username_gh = 'ErizaOffc' //Username GitHub
global.token_gh = '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'

// Vercel
global.vercelToken = 'BQBfZbIbJ9LECo0HslUjU6o1'

global.mess = {
  botAdmin: "🚩 Jadikan bot sebagai admin untuk menggunakan perintah ini & kalo bot nya Sudah jadi admin aktifkan di ubah hak admin",
  group: "🚩 Fitur ini hanya dapat digunakan di dalam grup",
  admin: "🚩 Hanya admin grup yang dapat menggunakan perintah ini",
  owner: "🚩 Hanya pemilik bot yang dapat menggunakan perintah ini",
  premium: "🚩 Fitur ini hanya dapat digunakan oleh pengguna premium",
  seller: "🚩 Anda belum memiliki akses sebagai seller",
  wait: "⌛ Sedang diproses...",
  done: "✅ Selesai!"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
