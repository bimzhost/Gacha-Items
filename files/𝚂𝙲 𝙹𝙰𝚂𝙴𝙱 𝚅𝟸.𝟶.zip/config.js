// config.js
module.exports = {
    BOT_TOKEN: "Token_Bot_Mu",
    ADMIN_ID: "Id_Tele_Lu"
};