// config.js
module.exports = {
 BOT_TOKEN: "8393654718:AAFV4QneSTsoI6G-jdvra7RqoNTc9v03Bww", 
 ADMIN_ID: 7880438807  
};